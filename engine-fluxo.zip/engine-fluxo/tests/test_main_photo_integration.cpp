// Réplica do loop real do main.cpp (não um teste isolado do
// ProjectivePipeline sozinho) -- confirma numericamente a integração
// completa: exclusão mútua Draw/Compile, frame_count_ sincronizado,
// sem loop infinito (timeout externo no shell é a rede de segurança,
// mas aqui confirmamos que termina em N iterações exatas).
#include "core/hardware_profiler.hpp"
#include "stream/slice_streamer.hpp"
#include "stream/window_controller.hpp"
#include "render/bounding_reference.hpp"
#include "render/projective_pipeline.hpp"
#include "render/cylindrical_photo_compiler.hpp"
#include <cstdio>

int main() {
    core::HardwareProfiler profiler;
    auto limits = profiler.Profile();

    stream::WindowController windowController(limits.max_window_slices);
    stream::SliceStreamer sliceStreamer("assets/world.stream");
    render::BoundingReference boundingRef;
    render::ProjectivePipeline pipeline(limits);
    render::CylindricalPhotoCompiler photoCompiler;

    if (!sliceStreamer.IsOpen()) {
        printf("FALHA: nao abriu assets/world.stream\n");
        return 1;
    }

    Vec3 cameraPos{0, 0, 0};
    int iteracoes = 0, frames_draw = 0, frames_photo = 0;
    const int LIMITE_SEGURANCA = 200; // nunca deveria chegar aqui se ShouldClose funciona

    bool running = true;
    while (running && iteracoes < LIMITE_SEGURANCA) {
        pipeline.AdvanceFrame();
        ++iteracoes;

        auto slice = sliceStreamer.PullSlice(cameraPos);
        windowController.Slide(cameraPos, slice);
        auto geometry = boundingRef.Evaluate(windowController.ActiveWindow());

        if (pipeline.ConsumePhotoRequest()) {
            std::vector<double> scales;
            for (auto& m : geometry.metrics) scales.push_back(m.a);
            auto photo = photoCompiler.Compile(windowController.ActiveWindow(), scales);
            ++frames_photo;
        } else {
            pipeline.Draw(geometry, cameraPos);
            pipeline.Present();
            ++frames_draw;
        }

        cameraPos = pipeline.PollCameraInput();
        running = !pipeline.ShouldClose();
    }

    printf("Iteracoes totais: %d\n", iteracoes);
    printf("Frames Draw: %d\n", frames_draw);
    printf("Frames Photo: %d\n", frames_photo);
    printf("Soma Draw+Photo == iteracoes? %s\n",
           (frames_draw + frames_photo == iteracoes) ? "SIM" : "NAO");
    printf("Terminou por ShouldClose (nao por limite de seguranca)? %s\n",
           (iteracoes < LIMITE_SEGURANCA) ? "SIM" : "NAO -- POSSIVEL LOOP INFINITO");

    bool ok = (iteracoes < LIMITE_SEGURANCA) &&
              (frames_draw + frames_photo == iteracoes) &&
              (frames_photo > 0) && (frames_draw > 0);
    printf("\n%s\n", ok ? "OK: integracao real confirmada" : "FALHA");
    return ok ? 0 : 1;
}
