#include "fold/fold_validation.hpp"
#include "symmetry/mirror_catalog.hpp"
#include "symmetry/horner_parity.hpp"
#include <cstdio>
#include <cmath>

using fold::FoldValidation;
using symmetry::MirrorCatalog;
using symmetry::HornerParity;
using symmetry::Point2;

int main() {
    bool tudo_ok = true;

    // 22.1 — Kawasaki/Maekawa: hexagonal regular deve passar Kawasaki
    bool kawasaki_hex = FoldValidation::TestaKawasaki({60,60,60,60,60,60});
    bool ok1 = (kawasaki_hex == true);
    tudo_ok &= ok1;
    printf("[22.1] Kawasaki hexagonal regular: %s (esperado true)\n",
           kawasaki_hex ? "true" : "false");

    // 22.1 — caso invalido conhecido: 70,110,70,110 falha Kawasaki (140 != 220)
    bool kawasaki_invalido = FoldValidation::TestaKawasaki({70,110,70,110});
    bool ok2 = (kawasaki_invalido == false);
    tudo_ok &= ok2;
    printf("[22.1] Kawasaki caso invalido (70,110,70,110): %s (esperado false)\n",
           kawasaki_invalido ? "true" : "false");

    // 22.3 — composicao L->V: dois L's, um espelhado verticalmente, unidos
    std::vector<Point2> L = {{0,0}, {1,-2}, {2,-2.5}};
    auto L_espelhado = MirrorCatalog::EspelhoVertical(L);
    auto V = MirrorCatalog::ComposePecas({L, L_espelhado});
    bool ok3 = (V.size() == 2 * L.size());
    tudo_ok &= ok3;
    printf("[22.3] V tem %zu pontos (esperado %zu)\n", V.size(), 2 * L.size());

    // 22.6 — colapso de Horner: raizes {7,5,3,1}, centro c=4 -> deslocamentos {3,1}
    // esperado: P(40) = 1666665, coefs Q(v) = [1, -10, 9]
    std::vector<double> coefs;
    double valor = HornerParity::AvaliaPorParidade(40.0, 4.0, {3.0, 1.0}, &coefs);
    bool ok4 = std::abs(valor - 1666665.0) < 1e-6;
    tudo_ok &= ok4;
    printf("[22.6] P(40) via paridade = %.1f (esperado 1666665.0), coefs Q = [%.0f, %.0f, %.0f]\n",
           valor, coefs[0], coefs[1], coefs[2]);

    int64_t trunc = HornerParity::TruncagemModularPorParidade(40.0, 4.0, {3.0, 1.0}, 9);
    bool ok5 = (trunc == 0);
    tudo_ok &= ok5;
    printf("[22.6] truncagem mod 9 = %lld (esperado 0)\n", (long long)trunc);

    printf("\n%s\n", tudo_ok
           ? "PARIDADE CONFIRMADA (C++ == Python == relatorio, Secao 22)"
           : "HA DIVERGENCIA");
    return tudo_ok ? 0 : 1;
}
