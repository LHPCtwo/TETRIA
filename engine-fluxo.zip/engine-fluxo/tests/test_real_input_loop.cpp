// Confirma que o loop completo usa input REAL quando disponível (via
// pipe simulando teclas), e cai em fallback simulado quando não há.
#include "core/hardware_profiler.hpp"
#include "stream/slice_streamer.hpp"
#include "stream/window_controller.hpp"
#include "render/bounding_reference.hpp"
#include "render/projective_pipeline.hpp"
#include <cstdio>

int main() {
    core::HardwareProfiler profiler;
    auto limits = profiler.Profile();
    render::ProjectivePipeline pipeline(limits);

    Vec3 pos{0, 0, 0};
    int frames = 0;
    bool algum_input_real = false;

    while (!pipeline.ShouldClose() && frames < 60) {
        pos = pipeline.PollCameraInput();
        if (pipeline.InputModeIsReal()) algum_input_real = true;
        ++frames;
    }

    printf("Frames rodados: %d\n", frames);
    printf("Posicao final: (%.1f, %.1f, %.1f)\n", pos.x, pos.y, pos.z);
    printf("Usou input real em algum momento: %s\n", algum_input_real ? "SIM" : "NAO");
    printf("InputModeIsReal() final: %s\n", pipeline.InputModeIsReal() ? "true" : "false");

    return 0;
}
