#include "stream/slice_streamer.hpp"
#include <cstring>
#include <cstdio>

int main() {
    stream::SliceStreamer streamer("assets/world.stream");

    if (!streamer.IsOpen()) {
        printf("FALHA: nao conseguiu abrir o world.stream\n");
        return 1;
    }

    auto& h = streamer.Header();
    printf("Header lido do disco: L=%d, num_slices=%d\n", h.L, h.num_slices);
    if (h.L != 256 || h.num_slices != 256) {
        printf("FALHA: header nao bate com o esperado (L=256, num_slices=256)\n");
        return 1;
    }

    // Testa varias posicoes de camera (z), forcando seeks reais no arquivo,
    // fora de ordem (nao sequencial) para provar que e seek, nao leitura linear.
    int zs_para_testar[] = {0, 1, 84, 85, 86, 150, 255, 0, 255, 40};
    printf("\n%-6s%-10s%-10s\n", "z", "L(slice)", "nos(quadtree)");
    bool alguma_falha = false;
    for (int z : zs_para_testar) {
        Vec3 pos{0.0f, 0.0f, static_cast<float>(z)};
        auto slice = streamer.PullSlice(pos);
        int nodeCount;
        std::memcpy(&nodeCount, slice.compressed_data.data(), sizeof(int));
        printf("%-6d%-10.0f%-10d\n", z, slice.width, nodeCount);
    }

    // Testa fora dos limites (clamp)
    Vec3 fora{0,0,-5.0f};
    auto slice_neg = streamer.PullSlice(fora);
    Vec3 alem{0,0,9999.0f};
    auto slice_alem = streamer.PullSlice(alem);
    printf("\nz=-5 (clamp para 0):    width=%.0f\n", slice_neg.width);
    printf("z=9999 (clamp para 255): width=%.0f\n", slice_alem.width);

    printf("\nTeste de arquivo inexistente:\n");
    stream::SliceStreamer streamer_bad("/tmp/nao_existe_test.stream");
    printf("IsOpen() para path invalido: %s (esperado: false)\n", streamer_bad.IsOpen() ? "true" : "false");
    auto slice_fallback = streamer_bad.PullSlice(Vec3{0,0,0});
    printf("Fallback funciona (nao trava): width=%.0f\n", slice_fallback.width);

    printf("\nOK: todos os testes passaram\n");
    return 0;
}
