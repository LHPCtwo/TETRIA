// Confirma que o loop real da engine mede (nao assume) o padrao de
// escala entre fatias da janela ativa, usando o world.stream sintetico
// existente.
#include "core/hardware_profiler.hpp"
#include "stream/slice_streamer.hpp"
#include "stream/window_controller.hpp"
#include "render/bounding_reference.hpp"
#include "render/projective_pipeline.hpp"
#include <cstdio>

int main() {
    core::HardwareProfiler profiler;
    auto limits = profiler.Profile();

    stream::WindowController windowController(limits.max_window_slices);
    stream::SliceStreamer sliceStreamer("assets/world.stream");
    render::BoundingReference boundingRef;
    render::ProjectivePipeline pipeline(limits);

    if (!sliceStreamer.IsOpen()) {
        printf("FALHA: nao abriu assets/world.stream\n");
        return 1;
    }

    Vec3 cameraPos{0, 0, 0};
    int frames_com_padrao_detectado = 0;

    for (int frame = 0; frame < 30; ++frame) {
        auto slice = sliceStreamer.PullSlice(cameraPos);
        windowController.Slide(cameraPos, slice);
        auto geometry = boundingRef.Evaluate(windowController.ActiveWindow());
        pipeline.Draw(geometry, cameraPos);

        auto& pattern = pipeline.LastScalePattern();
        if (pattern.model != render::ScalePattern::Model::kNeither) {
            ++frames_com_padrao_detectado;
            if (frame == 5 || frame == 15 || frame == 25) {
                const char* nome = "?";
                switch (pattern.model) {
                    case render::ScalePattern::Model::kLinear: nome = "linear"; break;
                    case render::ScalePattern::Model::kLogLinear: nome = "log-linear"; break;
                    case render::ScalePattern::Model::kBothDegenerate: nome = "degenerado"; break;
                    default: break;
                }
                printf("frame=%d: modelo=%s slope=%.4f var_linear=%.4f var_log=%.4e\n",
                       frame, nome, pattern.slope, pattern.var_linear, pattern.var_log);
            }
        }
        cameraPos.z += 1.0f;
    }

    printf("\nFrames com padrao detectado (nao 'nenhum'): %d/30\n", frames_com_padrao_detectado);
    return 0;
}
