#include "stream/spatial_partition.hpp"
#include <fstream>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <cstring>

int main(int argc, char** argv) {
    const char* path = argc > 1 ? argv[1] : "/home/claude/assets/world_bunny_sparse_32.stream";
    std::ifstream f(path, std::ios::binary);
    if (!f) { printf("FALHA: nao abriu %s\n", path); return 1; }

    char magic[4]; f.read(magic, 4);
    int32_t L, num_slices;
    f.read(reinterpret_cast<char*>(&L), 4);
    f.read(reinterpret_cast<char*>(&num_slices), 4);
    std::vector<int64_t> offsets(num_slices);
    f.read(reinterpret_cast<char*>(offsets.data()), 8*num_slices);

    int size = 1; while (size < L) size *= 2;

    long long trabalho_particiona = 0, trabalho_morton = 0, pontos_totais = 0;
    bool tudo_ok = true;

    for (int z = 0; z < num_slices; ++z) {
        f.seekg(offsets[z]);
        int32_t count;
        f.read(reinterpret_cast<char*>(&count), 4);
        std::vector<stream::SpatialPartitionSparse::Point> points(count);
        for (int i = 0; i < count; ++i) {
            uint16_t x, y;
            f.read(reinterpret_cast<char*>(&x), 2);
            f.read(reinterpret_cast<char*>(&y), 2);
            points[i] = {x, y};
        }
        pontos_totais += count;

        // versão v16 (particionamento em 1 passada)
        long long t1 = 0;
        auto tree1 = stream::SpatialPartitionSparse::Build(points, 0, 0, size, &t1);
        trabalho_particiona += t1;

        // versão v18 (Morton + busca binária) -- inclui o custo do sort
        // inicial (a v16/particionamento NAO precisa ordenar antes, entao
        // esse custo tem que ser contabilizado aqui pra comparacao justa)
        std::vector<stream::SpatialPartitionMorton::Point> mpoints(count);
        for (int i = 0; i < count; ++i) mpoints[i] = {points[i].x, points[i].y};
        long long comparacoes_sort = 0;
        std::sort(mpoints.begin(), mpoints.end(), [&](auto& a, auto& b) {
            if (comparacoes_sort >= 0) ++comparacoes_sort; // conta toda chamada do comparador
            return stream::SpatialPartitionMorton::Encode(a.x, a.y) <
                   stream::SpatialPartitionMorton::Encode(b.x, b.y);
        });
        long long t2 = comparacoes_sort;
        auto tree2 = stream::SpatialPartitionMorton::Build(mpoints, 0, mpoints.size(), 0, 0, size, &t2);
        trabalho_morton += t2;

        // paridade
        int n1 = tree1->NodeCount(), n2 = tree2->NodeCount();
        if (n1 != n2) {
            tudo_ok = false;
            printf("DIVERGIU em z=%d: particiona=%d morton=%d\n", z, n1, n2);
        }
    }

    printf("L=%d, %d fatias\n", L, num_slices);
    printf("pontos ocupados totais: %lld\n", pontos_totais);
    printf("trabalho particionamento (v16): %lld\n", trabalho_particiona);
    printf("trabalho Morton+busca binaria (v18): %lld\n", trabalho_morton);
    printf("razao morton/particiona: %.4f (quanto menor, melhor)\n",
           (double)trabalho_morton / trabalho_particiona);
    printf("\nParidade de resultado: %s\n", tudo_ok ? "OK, todas as fatias batem" : "HA DIVERGENCIA");
    return tudo_ok ? 0 : 1;
}
