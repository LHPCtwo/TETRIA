// Teste do loop completo: confirma numericamente (não só visualmente) que
// múltiplos frames reais rodam, cada um lendo disco de verdade via z
// diferente, e que o framebuffer muda entre frames (não é sempre o mesmo
// desenho estático).
#include "core/hardware_profiler.hpp"
#include "stream/slice_streamer.hpp"
#include "stream/window_controller.hpp"
#include "render/bounding_reference.hpp"
#include "render/projective_pipeline.hpp"
#include <cstdio>
#include <cstring>
#include <set>

int main() {
    core::HardwareProfiler profiler;
    auto limits = profiler.Profile();

    stream::WindowController windowController(limits.max_window_slices);
    stream::SliceStreamer sliceStreamer("assets/world.stream");
    render::BoundingReference boundingRef;
    render::ProjectivePipeline pipeline(limits);

    if (!sliceStreamer.IsOpen()) {
        printf("FALHA: nao abriu assets/world.stream (rodar a partir de /home/claude)\n");
        return 1;
    }

    Vec3 cameraPos{0,0,0};
    std::set<int> node_counts_vistos;
    int frames_rodados = 0;

    while (!pipeline.ShouldClose()) {
        pipeline.AdvanceFrame(); // v24: o contador avanca aqui, nao mais dentro de Present()
        auto slice = sliceStreamer.PullSlice(cameraPos);
        int nodeCount;
        std::memcpy(&nodeCount, slice.compressed_data.data(), sizeof(int));
        node_counts_vistos.insert(nodeCount);

        windowController.Slide(cameraPos, slice);
        auto geometry = boundingRef.Evaluate(windowController.ActiveWindow());
        pipeline.Draw(geometry, cameraPos);
        pipeline.Present();

        cameraPos = pipeline.PollCameraInput();
        ++frames_rodados;
    }

    printf("Frames rodados: %d (esperado: 60, nao mais 1)\n", frames_rodados);
    printf("Frame count reportado pelo pipeline: %d\n", pipeline.FrameCount());
    printf("Valores distintos de node_count vistos ao longo do voo: %zu\n", node_counts_vistos.size());
    printf("z final da camera simulada: %.1f (deve ter avancado, nao ficar em 0)\n", cameraPos.z);

    bool ok = (frames_rodados == 60) && (node_counts_vistos.size() > 1) && (cameraPos.z > 1.0f);
    printf("\n%s\n", ok ? "OK: loop real, disco real, dado muda ao longo do tempo" : "FALHA: algo nao esta variando como esperado");
    return ok ? 0 : 1;
}
