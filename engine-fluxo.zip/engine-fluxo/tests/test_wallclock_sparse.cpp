#include "stream/spatial_partition.hpp"
#include <fstream>
#include <cstdio>
#include <vector>
#include <chrono>

int main() {
    std::ifstream f("assets/world_bunny_sparse_64.stream", std::ios::binary);
    if (!f) { printf("FALHA\n"); return 1; }
    char magic[4]; f.read(magic, 4);
    int32_t L, num_slices;
    f.read(reinterpret_cast<char*>(&L), 4);
    f.read(reinterpret_cast<char*>(&num_slices), 4);
    std::vector<int64_t> offsets(num_slices);
    f.read(reinterpret_cast<char*>(offsets.data()), 8*num_slices);
    int size = 1; while (size < L) size *= 2;

    std::vector<std::vector<stream::SpatialPartitionSparse::Point>> todas_fatias(num_slices);
    for (int z = 0; z < num_slices; ++z) {
        f.seekg(offsets[z]);
        int32_t count;
        f.read(reinterpret_cast<char*>(&count), 4);
        todas_fatias[z].resize(count);
        for (int i = 0; i < count; ++i) {
            uint16_t x, y;
            f.read(reinterpret_cast<char*>(&x), 2);
            f.read(reinterpret_cast<char*>(&y), 2);
            todas_fatias[z][i] = {x, y};
        }
    }

    const int REPETICOES = 2000;

    // --- versao antiga ---
    auto t0 = std::chrono::high_resolution_clock::now();
    for (int r = 0; r < REPETICOES; ++r)
        for (int z = 0; z < num_slices; ++z)
            auto tree = stream::SpatialPartitionSparse::Build(todas_fatias[z], 0, 0, size);
    auto t1 = std::chrono::high_resolution_clock::now();
    double tempo_antigo = std::chrono::duration<double, std::milli>(t1 - t0).count();

    // --- versao in-place SEM copia (uso real: cada leitura de disco ja e um buffer novo) ---
    // recria os buffers a cada iteracao pra simular "acabou de ler do disco",
    // mas cronometra so a construcao da arvore, nao a criacao do buffer de teste
    std::vector<std::vector<stream::SpatialPartitionSparse::Point>> buffers_de_trabalho(num_slices);
    double tempo_inplace_total = 0;
    for (int r = 0; r < REPETICOES; ++r) {
        for (int z = 0; z < num_slices; ++z) {
            buffers_de_trabalho[z] = todas_fatias[z]; // simula "acabou de ler do disco" (fora do timing)
        }
        auto ta = std::chrono::high_resolution_clock::now();
        for (int z = 0; z < num_slices; ++z) {
            auto tree = stream::SpatialPartitionSparse::BuildInPlace(
                buffers_de_trabalho[z], 0, buffers_de_trabalho[z].size(), 0, 0, size);
        }
        auto tb = std::chrono::high_resolution_clock::now();
        tempo_inplace_total += std::chrono::duration<double, std::milli>(tb - ta).count();
    }

    printf("L=%d, %d fatias, %d repeticoes\n", L, num_slices, REPETICOES);
    printf("Tempo (com alocacao de vetores, versao v16): %.2f ms\n", tempo_antigo);
    printf("Tempo (in-place, SEM contar copia -- cenario real de uso): %.2f ms\n", tempo_inplace_total);
    printf("Razao: %.4f (in-place e %.1f%% mais rapido)\n",
           tempo_inplace_total/tempo_antigo, (1.0 - tempo_inplace_total/tempo_antigo)*100);
    return 0;
}
