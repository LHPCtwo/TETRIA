#include "procedural/diagonal_first.hpp"
#include <cstdio>

using procedural::DiagonalFirst;
using procedural::Cell;

int main() {
    bool tudo_ok = true;

    // 25.2 -- grade 14x6 deve reproduzir 67 diagonais / 9 retos / 7 saltos
    auto r = DiagonalFirst::Gera(14, 6);
    bool ok1 = (r.passos_diag == 67 && r.passos_reto == 9 && r.saltos == 7);
    bool cobertura_ok = (r.caminho.size() == 14 * 6);
    tudo_ok &= ok1 && cobertura_ok;
    printf("[25.2] grade 14x6: diag=%d reto=%d saltos=%d cobertura=%zu/%d (esperado 67/9/7, 84/84)\n",
           r.passos_diag, r.passos_reto, r.saltos, r.caminho.size(), 14*6);

    // 25.3 -- mascara em cunha deve gerar um caminho estritamente menor
    // que a grade completa, e ainda cobrir 100% das celulas validas
    auto mascara = DiagonalFirst::MascaraCunhaTransversal(28, 12);
    auto r2 = DiagonalFirst::Gera(28, 12, {0,0}, mascara);
    int total_valido = 0;
    for (int x = 0; x < 28; ++x)
        for (int y = 0; y < 12; ++y)
            if (mascara(x, y)) total_valido++;
    bool ok2 = (int(r2.caminho.size()) == total_valido) && (total_valido < 28*12);
    tudo_ok &= ok2;
    printf("[25.3] cunha 28x12: cobertura=%zu/%d celulas validas (esperado igual, e < %d total)\n",
           r2.caminho.size(), total_valido, 28*12);

    printf("\n%s\n", tudo_ok
           ? "PARIDADE CONFIRMADA (C++ == Python == relatorio, Secao 25)"
           : "HA DIVERGENCIA");
    return tudo_ok ? 0 : 1;
}
