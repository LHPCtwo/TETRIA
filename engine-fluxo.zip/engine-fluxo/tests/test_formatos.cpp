// Paridade de contagem de nós entre formatos do mesmo bunny, fatia a fatia.
// Uso: test_formatos <A.stream> <B.stream> [<C.stream> ...]
// Todos precisam ter o mesmo L e num_slices. Compara nodeCount de A contra cada outro,
// e mede tempo de parede por PullSlice (leitura + construção) em cada arquivo.
#include "stream/slice_streamer.hpp"
#include <chrono>
#include <cstdio>
#include <cstring>
#include <memory>
#include <vector>

static int NodeCount(const stream::Slice& s) {
    int n = 0;
    std::memcpy(&n, s.compressed_data.data(), sizeof(int));
    return n;
}

int main(int argc, char** argv) {
    if (argc < 3) { std::fprintf(stderr, "uso: %s A.stream B.stream [C.stream...]\n", argv[0]); return 2; }
    std::vector<std::unique_ptr<stream::SliceStreamer>> st;
    for (int i = 1; i < argc; ++i) {
        st.push_back(std::make_unique<stream::SliceStreamer>(argv[i]));
        if (!st.back()->IsOpen()) { std::fprintf(stderr, "não abriu/inválido: %s\n", argv[i]); return 2; }
        const auto& h = st.back()->Header();
        std::printf("%-55s fmt=%d L=%d fatias=%d\n", argv[i], static_cast<int>(h.format), h.L, h.num_slices);
    }
    const int n = st[0]->Header().num_slices;
    for (auto& s : st)
        if (s->Header().num_slices != n || s->Header().L != st[0]->Header().L) {
            std::fprintf(stderr, "L/num_slices diferem entre arquivos\n"); return 2;
        }

    int divergencias = 0;
    long long soma[16] = {0};
    for (int z = 0; z < n; ++z) {
        Vec3 cam{}; cam.z = static_cast<float>(z);
        int ref = NodeCount(st[0]->PullSlice(cam));
        soma[0] += ref;
        for (size_t k = 1; k < st.size(); ++k) {
            int v = NodeCount(st[k]->PullSlice(cam));
            soma[k] += v;
            if (v != ref) { ++divergencias; std::printf("  z=%d: A=%d  #%zu=%d  <-- diverge\n", z, ref, k, v); }
        }
    }
    std::printf("\nfatias comparadas: %d | divergências: %d\n", n, divergencias);
    for (size_t k = 0; k < st.size(); ++k) std::printf("  total de nós, arquivo #%zu: %lld\n", k, soma[k]);

    // tempo de parede: leitura + construção, todas as fatias, REP repetições
    const int REP = 200;
    for (size_t k = 0; k < st.size(); ++k) {
        auto t0 = std::chrono::steady_clock::now();
        long long sink = 0;
        for (int r = 0; r < REP; ++r)
            for (int z = 0; z < n; ++z) { Vec3 cam{}; cam.z = static_cast<float>(z); sink += NodeCount(st[k]->PullSlice(cam)); }
        auto t1 = std::chrono::steady_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
        std::printf("  tempo arquivo #%zu: %.0f ms (%d x %d PullSlice)  [sink=%lld]\n", k, ms, REP, n, sink);
    }
    return divergencias ? 1 : 0;
}
