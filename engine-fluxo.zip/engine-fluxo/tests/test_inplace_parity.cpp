#include "stream/spatial_partition.hpp"
#include <fstream>
#include <cstdio>
#include <vector>
#include <cstring>

int main() {
    std::ifstream f("assets/world_bunny_sparse_32.stream", std::ios::binary);
    if (!f) { printf("FALHA: nao abriu\n"); return 1; }

    char magic[4]; f.read(magic, 4);
    int32_t L, num_slices;
    f.read(reinterpret_cast<char*>(&L), 4);
    f.read(reinterpret_cast<char*>(&num_slices), 4);
    std::vector<int64_t> offsets(num_slices);
    f.read(reinterpret_cast<char*>(offsets.data()), 8*num_slices);

    int size = 1; while (size < L) size *= 2;

    bool tudo_ok = true;
    long long trabalho_antigo_total = 0, trabalho_inplace_total = 0;

    for (int z = 0; z < num_slices; ++z) {
        f.seekg(offsets[z]);
        int32_t count;
        f.read(reinterpret_cast<char*>(&count), 4);
        std::vector<stream::SpatialPartitionSparse::Point> points(count);
        for (int i = 0; i < count; ++i) {
            uint16_t x, y;
            f.read(reinterpret_cast<char*>(&x), 2);
            f.read(reinterpret_cast<char*>(&y), 2);
            points[i] = {x, y};
        }

        // versao antiga (aloca vetores)
        long long t1 = 0;
        auto tree1 = stream::SpatialPartitionSparse::Build(points, 0, 0, size, &t1);
        int n1 = tree1->NodeCount();

        // versao in-place (particiona sem alocar)
        std::vector<stream::SpatialPartitionSparse::Point> points_copia = points; // copia p/ nao afetar original
        long long t2 = 0;
        auto tree2 = stream::SpatialPartitionSparse::BuildInPlace(points_copia, 0, points_copia.size(), 0, 0, size, &t2);
        int n2 = tree2->NodeCount();

        trabalho_antigo_total += t1;
        trabalho_inplace_total += t2;

        if (n1 != n2) {
            tudo_ok = false;
            printf("DIVERGIU em z=%d: antigo=%d inplace=%d\n", z, n1, n2);
        }
    }

    printf("Paridade de resultado (todas as %d fatias): %s\n", num_slices, tudo_ok ? "OK, todas batem" : "HA DIVERGENCIA");
    printf("Trabalho (toques): antigo=%lld inplace=%lld (esperado: identico, mesma logica de particao)\n",
           trabalho_antigo_total, trabalho_inplace_total);
    return tudo_ok ? 0 : 1;
}
