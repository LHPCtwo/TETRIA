#include "symmetry/mirror_catalog.hpp"
#include <cstdio>
#include <cmath>

using symmetry::MirrorCatalog;
using symmetry::Point2;

int main() {
    Point2 origem{0.0, 0.0};
    double ang0 = M_PI / 2.0;
    Point2 dir0{std::cos(ang0), std::sin(ang0)};

    auto arvore = MirrorCatalog::ArvoreRecursiva(origem, dir0, 3.0, 5, 25.0, 0.72);

    printf("segmentos gerados: %zu (esperado 31, mesmo total da versao Python)\n", arvore.size());
    bool ok_total = (arvore.size() == 31);

    // Confere contra as pontas de referencia calculadas em Python
    // (arvore rigida, profundidade 5, angulo 25, fator 0.72) -- as 3
    // primeiras pontas do tronco/primeira bifurcacao, com tolerancia
    // numerica.
    auto perto = [](double a, double b) { return std::abs(a - b) < 1e-4; };

    // primeiro segmento = tronco, de (0,0) a (0,3) (direcao pi/2, comprimento 3)
    bool ok_tronco = perto(arvore[0].x0, 0.0) && perto(arvore[0].y0, 0.0)
                   && perto(arvore[0].x1, 0.0) && perto(arvore[0].y1, 3.0);
    printf("tronco: (%.4f,%.4f)->(%.4f,%.4f)  %s\n",
           arvore[0].x0, arvore[0].y0, arvore[0].x1, arvore[0].y1,
           ok_tronco ? "OK" : "DIVERGE (esperado (0,0)->(0,3))");

    bool tudo_ok = ok_total && ok_tronco;
    printf("\n%s\n", tudo_ok
           ? "PARIDADE CONFIRMADA (arvore = composicao V recursiva, mesma primitiva ja catalogada)"
           : "HA DIVERGENCIA");
    return tudo_ok ? 0 : 1;
}
