#include "symmetry/mirror_catalog.hpp"
#include <cstdio>

using symmetry::MirrorCatalog;

int conta_extremos_locais(const std::vector<double>& perfil) {
    std::vector<int> sinais;
    for (size_t i = 1; i < perfil.size(); ++i) {
        double d = perfil[i] - perfil[i - 1];
        if (d > 1e-9) sinais.push_back(1);
        else if (d < -1e-9) sinais.push_back(-1);
    }
    int trocas = 0;
    for (size_t i = 1; i < sinais.size(); ++i)
        if (sinais[i] != sinais[i - 1]) trocas++;
    return trocas;
}

int main() {
    // 1. agua = 1 reflexao, deve ser monotonica
    auto rampa = MirrorCatalog::OndaTriangularPorReflexao(60, 200.0, 1.0);
    printf("[agua] extremos = %d (esperado 0)\n", conta_extremos_locais(rampa));

    // 2. fumaca robusta em 10 seeds, mesmo criterio de tolerancia do Python
    int falhas = 0;
    for (unsigned seed = 1; seed <= 10; ++seed) {
        std::vector<int> vals;
        for (int n = 1; n <= 5; ++n) {
            auto p = MirrorCatalog::ReflexaoRecursivaMultiescala(60, n, 40.0, 1.8, 0.5, seed);
            vals.push_back(conta_extremos_locais(p));
        }
        bool quebrou = false;
        for (size_t i = 0; i + 1 < vals.size(); ++i)
            if (vals[i] > vals[i+1] + 1) quebrou = true;
        printf("seed=%2u: ", seed);
        for (int v : vals) printf("%d ", v);
        printf(" %s\n", quebrou ? "QUEBROU" : "ok");
        if (quebrou) falhas++;
    }
    printf("\n%s (%d/10 falhas)\n", falhas==0 ? "ROBUSTO" : "AINDA FRAGIL", falhas);
    return falhas == 0 ? 0 : 1;
}
