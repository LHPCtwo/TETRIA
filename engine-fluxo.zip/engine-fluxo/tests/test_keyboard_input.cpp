// Testa KeyboardInput com bytes REAIS enviados por stdin (via pipe) --
// prova que o mecanismo de leitura funciona de ponta a ponta, não que
// um humano está digitando (isso só um terminal interativo prova, mas
// o código é o mesmo em ambos os casos).
#include "render/keyboard_input.hpp"
#include <cstdio>

int main() {
    render::KeyboardInput kb;
    Vec3 pos{0, 0, 0};

    printf("IsInteractiveTTY: %s (esperado false, rodando via pipe)\n",
           kb.IsInteractiveTTY() ? "true" : "false");

    // dá tempo do pipe ter dados disponíveis (evita race de leitura vazia)
    for (int tentativa = 0; tentativa < 5; ++tentativa) {
        bool continuar = kb.PollAndApply(pos, 1.0f);
        printf("poll %d: pos=(%.1f,%.1f,%.1f) teve_input=%s continuar=%s\n",
               tentativa, pos.x, pos.y, pos.z,
               kb.LastPollHadInput() ? "sim" : "nao",
               continuar ? "sim" : "nao (q pressionado)");
        if (!continuar) break;
    }

    // valida contra o que sabemos que foi enviado: "wwwddq"
    // w x3 -> z+=3, d x2 -> x+=2, q -> sai
    bool ok = (pos.z == 3.0f) && (pos.x == 2.0f);
    printf("\nEsperado apos 'wwwddq': x=2.0 z=3.0 -- obtido: x=%.1f z=%.1f -- %s\n",
           pos.x, pos.z, ok ? "OK" : "FALHOU");
    return ok ? 0 : 1;
}
