"""
viewer.py — Visualizador TESS básico
Roda em Linux, Windows e macOS (Tkinter vem com Python)
Uso: python viewer.py [arquivo.tess]
"""
import tkinter as tk
from tkinter import filedialog
from PIL import Image, ImageTk, ImageDraw, ImageFont
import io, sys, zlib, struct

# reusar o decoder sem dependência de reportlab
from encoder_v2 import decode

def renderizar_em_memoria(doc, escala=1.0):
    """Renderiza o documento TESS numa imagem PIL (sem PDF, sem reportlab)."""
    pw, ph = doc['pagina']
    w = int(pw * escala)
    h = int(ph * escala)
    img = Image.new('RGB', (w, h), 'white')
    draw = ImageDraw.Draw(img)

    for b in doc['blocos']:
        x = int(b['x'] * escala)
        y = int((ph - b['y'] - b['h']) * escala)  # PDF tem y invertido
        bw = int(b['w'] * escala)
        bh = int(b['h'] * escala)

        if b['tipo'] == 'texto':
            nome, tam = doc['fontes'][b['fonte_id']]
            tam_px = max(8, int(tam * escala * 0.8))
            try:
                fonte = ImageFont.truetype("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf", tam_px)
            except:
                fonte = ImageFont.load_default()
            # quebrar texto na largura do bloco
            palavras = b['texto'].split()
            linhas = []
            linha_atual = ""
            for p in palavras:
                teste = linha_atual + (" " if linha_atual else "") + p
                bbox = draw.textbbox((0,0), teste, font=fonte)
                if bbox[2] - bbox[0] <= bw:
                    linha_atual = teste
                else:
                    if linha_atual:
                        linhas.append(linha_atual)
                    linha_atual = p
            if linha_atual:
                linhas.append(linha_atual)
            y_cur = y
            for linha in linhas:
                if y_cur > y + bh:
                    break
                draw.text((x, y_cur), linha, fill='black', font=fonte)
                y_cur += tam_px + 2

        elif b['tipo'] == 'imagem':
            try:
                im = Image.open(io.BytesIO(b['img_bytes']))
                # redimensionar preservando proporção
                im.thumbnail((bw, bh), Image.LANCZOS)
                img.paste(im, (x, y))
            except Exception as e:
                draw.rectangle([x, y, x+bw, y+bh], outline='gray')
                draw.text((x+4, y+4), f"[imagem]", fill='gray')

    return img

class ViewerTESS:
    def __init__(self, root):
        self.root = root
        self.root.title("TESS Viewer")
        self.root.configure(bg='#2b2b2b')
        self.doc = None
        self.escala = 1.0
        self._construir_ui()

    def _construir_ui(self):
        # barra de ferramentas
        barra = tk.Frame(self.root, bg='#3c3c3c', pady=4)
        barra.pack(fill='x')
        tk.Button(barra, text="Abrir .tess", command=self.abrir,
                  bg='#555', fg='white', relief='flat', padx=10).pack(side='left', padx=4)
        tk.Button(barra, text="−", command=lambda: self.zoom(-0.1),
                  bg='#555', fg='white', relief='flat', padx=8).pack(side='left')
        tk.Button(barra, text="+", command=lambda: self.zoom(+0.1),
                  bg='#555', fg='white', relief='flat', padx=8).pack(side='left')
        self.lbl_info = tk.Label(barra, text="Nenhum arquivo aberto",
                                  bg='#3c3c3c', fg='#aaa', padx=10)
        self.lbl_info.pack(side='left')

        # área de visualização com scroll
        frame = tk.Frame(self.root, bg='#2b2b2b')
        frame.pack(fill='both', expand=True)
        self.canvas = tk.Canvas(frame, bg='#2b2b2b', highlightthickness=0)
        sb_v = tk.Scrollbar(frame, orient='vertical', command=self.canvas.yview)
        sb_h = tk.Scrollbar(self.root, orient='horizontal', command=self.canvas.xview)
        self.canvas.configure(yscrollcommand=sb_v.set, xscrollcommand=sb_h.set)
        sb_v.pack(side='right', fill='y')
        self.canvas.pack(side='left', fill='both', expand=True)
        sb_h.pack(fill='x')
        self.canvas.bind("<MouseWheel>", self._scroll)
        self.canvas.bind("<Button-4>", self._scroll)
        self.canvas.bind("<Button-5>", self._scroll)

    def abrir(self, path=None):
        if not path:
            path = filedialog.askopenfilename(
                filetypes=[("TESS", "*.tess"), ("Todos", "*.*")])
        if not path:
            return
        with open(path, 'rb') as f:
            data = f.read()
        self.doc = decode(data)
        self.lbl_info.config(text=f"{path.split('/')[-1]}  —  "
                             f"{len(self.doc['blocos'])} blocos  |  "
                             f"{len(data)} bytes")
        self.renderizar()

    def renderizar(self):
        if not self.doc:
            return
        img = renderizar_em_memoria(self.doc, self.escala)
        self._tk_img = ImageTk.PhotoImage(img)
        self.canvas.delete('all')
        self.canvas.create_image(10, 10, anchor='nw', image=self._tk_img)
        self.canvas.config(scrollregion=(0, 0,
                           img.width + 20, img.height + 20))

    def zoom(self, delta):
        self.escala = max(0.3, min(3.0, self.escala + delta))
        self.renderizar()

    def _scroll(self, e):
        if e.num == 4 or e.delta > 0:
            self.canvas.yview_scroll(-1, 'units')
        else:
            self.canvas.yview_scroll(1, 'units')

if __name__ == '__main__':
    root = tk.Tk()
    root.geometry('700x900')
    app = ViewerTESS(root)
    if len(sys.argv) > 1:
        app.abrir(sys.argv[1])
    root.mainloop()
