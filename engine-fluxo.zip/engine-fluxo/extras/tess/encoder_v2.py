"""
encoder_v2.py — Encoder/Decoder TESS v2 (mídia mista: texto + imagem)
Formato aberto. Licença MIT.
"""
import struct, zlib

MAGIC = b"TESS"
VERSION = 2

# ── ESTRUTURA DO FORMATO v2 ───────────────────────────────────────────
# HEADER (12 bytes, 1 vez):
#   magic     4b  "TESS"
#   versao    1b  (2)
#   n_fontes  1b
#   n_blocos  2b  uint16
#   w_pagina  2b  uint16 (décimos de pt)
#   h_pagina  2b  uint16
#
# FONTE (por família, 1 vez):
#   nome_len  1b
#   nome      nome_len bytes UTF-8
#   tamanho   1b (pt)
#
# BLOCO (overhead fixo: 9 bytes de coordenadas + 1 byte de tipo):
#   x, y, w, h  4×uint16 (décimos de pt)
#   tipo        1b  (0=texto, 1=imagem)
#
#   Se tipo == 0 (texto):
#     fonte_id  1b
#     txt_len   2b uint16
#     txt       txt_len bytes (UTF-8, zlib nível 9)
#
#   Se tipo == 1 (imagem):
#     fmt       1b  (0=PNG, 1=JPEG)
#     img_len   4b  uint32
#     img_data  img_len bytes (bytes brutos do arquivo)
# ─────────────────────────────────────────────────────────────────────

def encode(pagina_w, pagina_h, fontes, blocos):
    """
    pagina_w, pagina_h : float (pontos tipográficos)
    fontes : lista de (nome_str, tamanho_int)
    blocos : lista de dicts, cada um com:
        tipo='texto' → {'x','y','w','h','fonte_id','texto'}
        tipo='imagem'→ {'x','y','w','h','fmt','img_bytes'}
                       fmt: 0=PNG, 1=JPEG
    Retorna bytes do arquivo .tess
    """
    out = bytearray()
    out += MAGIC
    out += struct.pack('B', VERSION)
    out += struct.pack('B', len(fontes))
    out += struct.pack('>H', len(blocos))
    out += struct.pack('>H', int(pagina_w * 10))
    out += struct.pack('>H', int(pagina_h * 10))
    for nome, tam in fontes:
        nb = nome.encode('utf-8')
        out += struct.pack('B', len(nb))
        out += nb
        out += struct.pack('B', tam)
    for b in blocos:
        out += struct.pack('>H', int(b['x'] * 10))
        out += struct.pack('>H', int(b['y'] * 10))
        out += struct.pack('>H', int(b['w'] * 10))
        out += struct.pack('>H', int(b['h'] * 10))
        if b['tipo'] == 'texto':
            out += struct.pack('B', 0)
            txt = zlib.compress(b['texto'].encode('utf-8'), level=9)
            out += struct.pack('B', b['fonte_id'])
            out += struct.pack('>H', len(txt))
            out += txt
        elif b['tipo'] == 'imagem':
            out += struct.pack('B', 1)
            out += struct.pack('B', b['fmt'])
            out += struct.pack('>I', len(b['img_bytes']))
            out += b['img_bytes']
    return bytes(out)

def encode_from_files(pagina_w, pagina_h, fontes, blocos_spec):
    """
    Variante que aceita 'path' em vez de 'img_bytes' para imagens.
    """
    blocos = []
    for b in blocos_spec:
        if b['tipo'] == 'imagem':
            fmt = 0 if b['path'].lower().endswith('.png') else 1
            with open(b['path'], 'rb') as f:
                img = f.read()
            blocos.append({**b, 'fmt': fmt, 'img_bytes': img})
        else:
            blocos.append(b)
    return encode(pagina_w, pagina_h, fontes, blocos)

def decode(data):
    """
    Retorna dict:
      { 'pagina': (w, h),
        'fontes': [(nome, tam), ...],
        'blocos': [dict por bloco] }
    """
    pos = 0
    def read(n):
        nonlocal pos
        chunk = data[pos:pos+n]; pos += n; return chunk

    assert read(4) == MAGIC, "Magic inválido — não é um arquivo TESS"
    ver      = struct.unpack('B', read(1))[0]
    n_fontes = struct.unpack('B', read(1))[0]
    n_blocos = struct.unpack('>H', read(2))[0]
    pw = struct.unpack('>H', read(2))[0] / 10
    ph = struct.unpack('>H', read(2))[0] / 10

    fontes = []
    for _ in range(n_fontes):
        nl   = struct.unpack('B', read(1))[0]
        nome = read(nl).decode('utf-8')
        tam  = struct.unpack('B', read(1))[0]
        fontes.append((nome, tam))

    blocos = []
    for _ in range(n_blocos):
        x = struct.unpack('>H', read(2))[0] / 10
        y = struct.unpack('>H', read(2))[0] / 10
        w = struct.unpack('>H', read(2))[0] / 10
        h = struct.unpack('>H', read(2))[0] / 10
        tipo = struct.unpack('B', read(1))[0]
        if tipo == 0:
            fid    = struct.unpack('B', read(1))[0]
            tl     = struct.unpack('>H', read(2))[0]
            texto  = zlib.decompress(read(tl)).decode('utf-8')
            blocos.append({'tipo':'texto','x':x,'y':y,'w':w,'h':h,
                           'fonte_id':fid,'texto':texto})
        elif tipo == 1:
            fmt    = struct.unpack('B', read(1))[0]
            il     = struct.unpack('>I', read(4))[0]
            img    = read(il)
            blocos.append({'tipo':'imagem','x':x,'y':y,'w':w,'h':h,
                           'fmt':fmt,'img_bytes':img})
    return {'versao': ver, 'pagina': (pw, ph),
            'fontes': fontes, 'blocos': blocos}


# ── TESTE RÁPIDO ──────────────────────────────────────────────────────
if __name__ == '__main__':
    import os

    fontes = [("Helvetica", 12), ("Helvetica", 10)]
    m = 72; larg = 595 - 2*m

    blocos_spec = [
        {'tipo':'texto','x':m,'y':750,'w':larg,'h':40,'fonte_id':0,
         'texto':'Figura 1: Malha triangular com vizinhança hexagonal.'},
        {'tipo':'imagem','x':m,'y':480,'w':larg,'h':260,
         'path':'hexlattice.png'},
        {'tipo':'texto','x':m,'y':460,'w':larg,'h':20,'fonte_id':1,
         'texto':'Todo ponto interno tem 6 vizinhos equidistantes — hexágono regular confirmado.'},
        {'tipo':'texto','x':m,'y':390,'w':larg,'h':60,'fonte_id':0,
         'texto':'Overhead fixo de estrutura: 74 bytes para 4 blocos (3 texto + 1 imagem). '
                 'O peso real do arquivo é determinado pelo conteúdo, não pela estrutura.'},
    ]

    encoded = encode_from_files(595, 842, fontes, blocos_spec)
    with open("doc_misto.tess", "wb") as f:
        f.write(encoded)

    doc = decode(encoded)
    textos_ok = all(
        b['texto'] == blocos_spec[i]['texto']
        for i, b in enumerate(doc['blocos'])
        if b['tipo'] == 'texto'
    )
    img_ok = doc['blocos'][1]['img_bytes'] == open('hexlattice.png','rb').read()

    print(f"Arquivo: {len(encoded)} bytes")
    print(f"Blocos decodificados: {len(doc['blocos'])}")
    print(f"Texto OK: {textos_ok}  |  Imagem OK: {img_ok}")
    print(f"Overhead estrutura: {12 + sum(len(f[0].encode())+2 for f in fontes) + len(blocos_spec)*10} bytes")
