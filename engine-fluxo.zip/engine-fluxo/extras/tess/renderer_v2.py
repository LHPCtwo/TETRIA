"""
renderer_v2.py — Renderizador TESS v2 (texto + imagem) → PDF
Licença MIT.
"""
from encoder_v2 import decode
from reportlab.pdfgen import canvas
from reportlab.lib.utils import simpleSplit, ImageReader
import sys, os, io

def render(tess_path, out_pdf):
    with open(tess_path, 'rb') as f:
        data = f.read()
    doc = decode(data)
    pw, ph   = doc['pagina']
    fontes   = doc['fontes']
    blocos   = doc['blocos']

    c = canvas.Canvas(out_pdf, pagesize=(pw, ph))

    for b in blocos:
        x, y, w, h = b['x'], b['y'], b['w'], b['h']

        if b['tipo'] == 'texto':
            nome, tam = fontes[b['fonte_id']]
            fonte_rl  = nome if nome in ['Helvetica','Times-Roman','Courier'] else 'Helvetica'
            c.setFont(fonte_rl, tam)
            linhas   = simpleSplit(b['texto'], fonte_rl, tam, w)
            y_cursor = y + h - tam
            for linha in linhas:
                if y_cursor < y: break
                c.drawString(x, y_cursor, linha)
                y_cursor -= tam * 1.2

        elif b['tipo'] == 'imagem':
            img_io = io.BytesIO(b['img_bytes'])
            img    = ImageReader(img_io)
            c.drawImage(img, x, y, width=w, height=h,
                        preserveAspectRatio=True, mask='auto')

    c.save()
    print(f"Renderizado: {out_pdf}  ({os.path.getsize(out_pdf)} bytes)")

if __name__ == '__main__':
    tess = sys.argv[1] if len(sys.argv) > 1 else 'doc_misto.tess'
    out  = sys.argv[2] if len(sys.argv) > 2 else 'doc_misto_renderizado.pdf'
    render(tess, out)
