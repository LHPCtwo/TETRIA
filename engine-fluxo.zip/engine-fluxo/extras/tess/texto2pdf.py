"""
texto2pdf.py — Cola texto, recebe PDF.
Uso: python texto2pdf.py
"""
import os, sys
from reportlab.pdfgen import canvas
from reportlab.lib.utils import simpleSplit

MARGEM   = 72
LARG     = 595 - 2*MARGEM
FONTE    = 'Helvetica'
TAM      = 12
LINHA_H  = TAM * 1.2   # espaço entre linhas
ENTRE    = TAM * 0.6   # espaço entre parágrafos (meio line-height)

def gerar_pdf(texto, out_pdf):
    paragrafos = [p.strip() for p in texto.strip().split('\n') if p.strip()]
    c = canvas.Canvas(out_pdf, pagesize=(595, 842))
    y = 842 - MARGEM

    def nova_pagina():
        nonlocal y
        c.showPage()
        y = 842 - MARGEM

    c.setFont(FONTE, TAM)
    for par in paragrafos:
        linhas = simpleSplit(par, FONTE, TAM, LARG)
        h_par = len(linhas) * LINHA_H
        if y - h_par < MARGEM:
            nova_pagina()
            c.setFont(FONTE, TAM)
        for linha in linhas:
            c.drawString(MARGEM, y, linha)
            y -= LINHA_H
        y -= ENTRE   # espaço entre parágrafos

    c.save()
    print(f"✓ {out_pdf}  ({os.path.getsize(out_pdf)} bytes)")

# ── MAIN ─────────────────────────────────────────────────────────────
print("Cole o texto abaixo. Linha em branco entre parágrafos.")
print("Quando terminar, digite uma linha com só '---' e Enter.\n")

linhas = []
while True:
    try:
        linha = input()
        if linha.strip() == '---':
            break
        linhas.append(linha)
    except EOFError:
        break

texto = '\n'.join(linhas)
if not texto.strip():
    print("Nenhum texto.")
    sys.exit(0)

nome = input("\nNome do PDF (sem extensão): ").strip() or "saida"
out  = nome + ".pdf"
gerar_pdf(texto, out)
copiar = input(f"Copiar para /sdcard/Download/? (s/n): ").strip().lower()
if copiar == 's':
    os.system(f'cp "{out}" /sdcard/Download/')
    print(f"✓ Copiado para /sdcard/Download/{out}")
