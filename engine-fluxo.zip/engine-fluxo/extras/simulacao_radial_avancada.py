# -*- coding: utf-8 -*-
import math
import time

class NoRadial:
    def __init__(self, id_no, camada, distancia_centro):
        self.id_no = id_no
        self.camada = camada
        self.distancia_centro = distancia_centro
        self.carga = 0.0
        self.temperatura = 25.0  # Temperatura base em Celsius

def simular_sistema_radial(total_dados, total_nos=10000, raio_maximo=5.0):
    print(f"\n--- SIMULANDO ESTRESSE MASSIVO: {total_nos} NÓS (MODELO RADIAL) ---")
    
    # Criando os nós na malha radial (grafo)
    # O ganho radial distribui os nós em camadas circulares proporcionais
    nos = []
    camadas = int(math.sqrt(total_nos))
    nos_por_camada = total_nos // camadas
    
    id_atual = 1
    for c in range(1, camadas + 1):
        distancia = (c / camadas) * raio_maximo
        for _ in range(nos_por_camada):
            if id_atual <= total_nos:
                nos.append(NoRadial(id_atual, c, distancia))
                id_atual += 1
                
    # O rio jorra do centro: divisão puramente simétrica instantânea
    inicio = time.perf_counter()
    carga_por_no = total_dados / len(nos)
    
    # Alocação radial imediata sem filas
    for no in nos:
        no.carga = carga_por_no
        
        # O calor gerado é inversamente proporcional à distância do raio central (dissipação radial natural)
        # O trabalho se espalha e diminui a densidade térmica por área periférica
        no.temperatura += (carga_por_no * 0.005) / (no.distancia_centro ** 2)
        
    fim = time.perf_counter()
    
    # Métricas
    ociosidade = sum(1 for no in nos if no.carga == 0) / len(nos) * 100
    temp_max = max(no.temperatura for no in nos)
    temp_min = min(no.temperatura for no in nos)
    temp_media = sum(no.temperatura for no in nos) / len(nos)
    
    print(f"Dados totais distribuídos: {total_dados} unidades")
    print(f"Total de nós periféricos ativos: {len(nos)}")
    print(f"Ociosidade na rede radial: {ociosidade:.1f}%")
    print(f"Tempo de alocação em grafo massivo: {fim - inicio:.7f} segundos")
    print(f"Mapeamento Térmico Dinâmico:")
    print(f"  -> Temperatura máxima (próxima ao centro): {temp_max:.2f}°C")
    print(f"  -> Temperatura mínima (extrema periferia): {temp_min:.2f}°C")
    print(f"  -> Temperatura média da malha: {temp_media:.2f}°C")
    print("Conclusão: Dissipação térmica radial equilibrada sem picos de retenção por fila.")

if __name__ == '__main__':
    # Roda a simulação massiva combinando milhares de nós + cálculo térmico
    simular_sistema_radial(total_dados=50000000, total_nos=10000)
