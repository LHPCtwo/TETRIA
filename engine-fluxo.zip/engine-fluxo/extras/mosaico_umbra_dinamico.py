# -*- coding: utf-8 -*-
import math
import time

def gerar_mosaico_dinamico(escala=1.0):
    """
    Gera o padrão geométrico da umbra (ampulheta/pássaro) baseado em reflexão
    pura e matrizes discretas. Permite alterar o tamanho (escala) dinamicamente.
    """
    # Sequência numérica base das asas (contagem original de pontos)
    passos_base = [6, 10, 14, 18, 14, 10, 6]
    
    # Aplica o modificador numérico de escala (ajustando para manter números pares e simétricos)
    passos = [max(2, int(p * escala) - (int(p * escala) % 2)) for p in passos_base]
    largura_maxima = max(passos) + 4
    
    def renderizar_linha(pontos):
        espacos = (largura_maxima - pontos) // 2
        return " " * espacos + "•" * pontos + " " * espacos

    linhas = []
    
    # Asa Superior
    for p in passos:
        linhas.append(renderizar_linha(p))
        
    # Encaixe Central (O corpo da ampulheta ajustado à escala)
    corpo = max(2, int(6 * escala) - (int(6 * escala) % 2))
    for _ in range(max(1, int(3 * escala))):
        linhas.append(renderizar_linha(corpo))
        
    # Asa Inferior (Espelhamento perfeito)
    for p in passos:
        linhas.append(renderizar_linha(p))
        
    return linhas

if __name__ == "__main__":
    print("-" * 40)
    print("  MOSAICO DA UMBRA: GEOMETRIA DOS NÚMEROS")
    print("-" * 40)
    
    # Simula a renderização em diferentes escalas numéricas (efeito de zoom)
    for tamanho in [0.7, 1.0, 1.4]:
        print(f"\n[ Escala do Padrão Numérico: {tamanho} ]\n")
        linhas_mosaico = gerar_mosaico_dinamico(tamanho)
        for linha in linhas_mosaico:
            print(linha)
        time.sleep(0.5)
