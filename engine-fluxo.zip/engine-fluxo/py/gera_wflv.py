"""Converte um .stream WFLS (esparso, pares x,y) em WFLV (vértice+delta varint).

Uso: python3 -I gera_wflv.py entrada_WFLS.stream saida_WFLV.stream

WFLV (little-endian), igual ao comentário de slice_streamer.hpp (v27):
  MAGIC "WFLV" | L int32 | num_slices int32
  índice: num_slices x offset int64 (posição absoluta no arquivo)
  por fatia: count int32 | byte_length int32 | bytes (varint LEB128 dos deltas)
vértice: val = y*W + x + 1, W = L, pontos ordenados por val.
"""
import os
import struct
import sys


def le_wfls(path):
    with open(path, "rb") as f:
        assert f.read(4) == b"WFLS", "magic não é WFLS"
        L, n = struct.unpack("<ii", f.read(8))
        offs = struct.unpack(f"<{n}q", f.read(8 * n))
        fatias = []
        for z in range(n):
            f.seek(offs[z])
            (count,) = struct.unpack("<i", f.read(4))
            raw = f.read(4 * count)
            fatias.append([struct.unpack_from("<HH", raw, 4 * i) for i in range(count)])
    return L, n, fatias


def varint(n, out):
    while True:
        b = n & 0x7F
        n >>= 7
        if n:
            out.append(b | 0x80)
        else:
            out.append(b)
            return


def encode(points, W):
    pts = sorted(points, key=lambda p: p[1] * W + p[0])
    out = bytearray()
    prev = 0
    for x, y in pts:
        val = y * W + x + 1
        varint(val - prev, out)
        prev = val
    return bytes(out)


def decode(data, W):
    pts, pos, prev = [], 0, 0
    while pos < len(data):
        r, sh = 0, 0
        while True:
            b = data[pos]
            pos += 1
            r |= (b & 0x7F) << sh
            if not (b & 0x80):
                break
            sh += 7
        prev += r
        v0 = prev - 1
        pts.append((v0 % W, v0 // W))
    return pts


def main(src, dst):
    L, n, fatias = le_wfls(src)
    corpos = [encode(p, L) for p in fatias]
    with open(dst, "wb") as f:
        f.write(b"WFLV")
        f.write(struct.pack("<ii", L, n))
        idx_pos = f.tell()
        f.write(b"\x00" * (8 * n))
        offs = []
        for p, c in zip(fatias, corpos):
            offs.append(f.tell())
            f.write(struct.pack("<ii", len(p), len(c)))
            f.write(c)
        f.seek(idx_pos)
        for o in offs:
            f.write(struct.pack("<q", o))

    # round-trip: relê o WFLV gravado e compara como CONJUNTO por fatia
    with open(dst, "rb") as f:
        assert f.read(4) == b"WFLV"
        L2, n2 = struct.unpack("<ii", f.read(8))
        offs2 = struct.unpack(f"<{n2}q", f.read(8 * n2))
        falhas = 0
        for z in range(n2):
            f.seek(offs2[z])
            count, blen = struct.unpack("<ii", f.read(8))
            pts = decode(f.read(blen), L2)
            if len(pts) != count or set(pts) != set(map(tuple, fatias[z])):
                falhas += 1
    total = sum(len(p) for p in fatias)
    print(f"L={L} fatias={n} pontos={total}")
    print(f"WFLS (entrada): {os.path.getsize(src):,} bytes")
    print(f"WFLV (saída)  : {os.path.getsize(dst):,} bytes")
    print(f"round-trip por conjunto: {falhas} falhas em {n2} fatias")
    sys.exit(1 if falhas else 0)


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])
