"""
Gera world_bunny.stream: mesmo family de asset que world.stream
(py/gera_world_stream.py), mas com dado REAL (Stanford Bunny voxelizado),
não parâmetros algébricos (k,c).

Fecha a lacuna registrada no README v12 item 6: a validação do bunny
(py/voxeliza_bunny_real.py) ficou só em Python -- a engine C++ nunca leu
esse dado real, só o world.stream sintético. Este script grava um
formato novo que a engine consegue ler e comprimir de fato.

Formato (little-endian):

  header:  MAGIC (4 bytes ASCII "WFLB") | L (int32) | num_slices (int32)
  por fatia (num_slices vezes): L*L bits, empacotados 8 por byte
  (ceil(L*L/8) bytes por fatia), 1 = ocupado, 0 = vazio -- um bitmap
  raster real da fatia z do bunny voxelizado, não uma fórmula.

Diferente do world.stream original (formato "WFLX", que guarda só 2
inteiros k,c por fatia porque a malha é gerada por fórmula fechada), o
bunny não tem fórmula fechada -- é dado de superfície real, então cada
fatia precisa do bitmap completo.
"""
import struct
import sys
import os

MAGIC = b"WFLB"


def gera_world_bunny_stream(path: str, obj_path: str, L: int):
    # reusa a voxelização já validada em voxeliza_bunny_real.py
    _here = os.path.dirname(os.path.abspath(__file__))
    import importlib.util
    spec = importlib.util.spec_from_file_location("vb", os.path.join(_here, "voxeliza_bunny_real.py"))
    vb = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(vb)

    vertices, faces = vb.le_obj_vertices_faces(obj_path)
    ocupado = vb.voxeliza_superficie(vertices, faces, L)
    print(f"Voxelizado: {len(ocupado):,} voxels ocupados de {L**3:,} "
          f"({len(ocupado)/L**3*100:.2f}%)")

    bytes_por_fatia = (L * L + 7) // 8

    with open(path, "wb") as f:
        f.write(MAGIC)
        f.write(struct.pack("<i", L))
        f.write(struct.pack("<i", L))  # num_slices = L (uma fatia por z)

        for z in range(L):
            bitmap = bytearray(bytes_por_fatia)
            for x in range(L):
                for y in range(L):
                    if (x, y, z) in ocupado:
                        idx = y * L + x
                        bitmap[idx // 8] |= (1 << (idx % 8))
            f.write(bytes(bitmap))

    print(f"Gravado {path}: L={L}, {L} fatias, {bytes_por_fatia} bytes/fatia, "
          f"total {os.path.getsize(path):,} bytes")


def le_world_bunny_stream(path: str):
    """Leitura de verificação (espelha o que o SliceStreamer em C++ vai fazer)."""
    with open(path, "rb") as f:
        magic = f.read(4)
        assert magic == MAGIC, f"magic invalido: {magic}"
        L, num_slices = struct.unpack("<ii", f.read(8))
        bytes_por_fatia = (L * L + 7) // 8
        fatias = []
        for _ in range(num_slices):
            data = f.read(bytes_por_fatia)
            fatias.append(data)
    return L, num_slices, fatias


def bitmap_para_ocupados(bitmap: bytes, L: int, z: int):
    ocupado = set()
    for idx in range(L * L):
        if bitmap[idx // 8] & (1 << (idx % 8)):
            x, y = idx % L, idx // L
            ocupado.add((x, y, z))
    return ocupado


if __name__ == "__main__":
    L = int(sys.argv[1]) if len(sys.argv) > 1 else 32
    out_path = sys.argv[2] if len(sys.argv) > 2 else f"world_bunny_{L}.stream"
    obj_path = "/home/claude/stanford-bunny.obj"

    gera_world_bunny_stream(out_path, obj_path, L)

    # verificação: relê o arquivo e confirma que bate com a voxelização direta
    print("\n--- Verificação de reconstrução ---")
    L2, n2, fatias = le_world_bunny_stream(out_path)
    assert L2 == L and n2 == L

    import importlib.util, os as _os
    _here = _os.path.dirname(_os.path.abspath(__file__))
    spec = importlib.util.spec_from_file_location("vb", _os.path.join(_here, "voxeliza_bunny_real.py"))
    vb = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(vb)
    vertices, faces = vb.le_obj_vertices_faces(obj_path)
    ocupado_direto = vb.voxeliza_superficie(vertices, faces, L)

    total_reconstruido = 0
    for z, bitmap in enumerate(fatias):
        total_reconstruido += bin(int.from_bytes(bitmap, "little")).count("1")

    print(f"voxels ocupados (voxelização direta): {len(ocupado_direto):,}")
    print(f"voxels ocupados (relidos do arquivo):  {total_reconstruido:,}")
    print(f"bate? {'SIM' if len(ocupado_direto) == total_reconstruido else 'NAO'}")
