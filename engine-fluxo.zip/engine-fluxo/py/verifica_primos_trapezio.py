"""
Verifica o Teorema 3.1 do documento: N impar > 1 e primo <=> existe
exatamente 1 decomposicao trapezoidal nao trivial (h>=2), e essa
decomposicao tem h=2 sempre.
"""
import sympy

def decomposicoes_trapezoidais(N, h_min=2):
    """Busca exaustiva: todos os (a,b) com b>a>=0, b-a>=h_min, Tb-Ta=N."""
    resultados = []
    # Tb - Ta = (b-a)(b+a+1)/2 = N  =>  (b-a)(b+a+1) = 2N
    for b in range(0, 2*N+2):
        for a in range(0, b):
            if b - a < h_min:
                continue
            Tb = b*(b+1)//2
            Ta = a*(a+1)//2
            if Tb - Ta == N:
                resultados.append((a, b, b-a))
    return resultados

def testa_teorema(limite=50):
    print(f"{'N':>4} {'primo?':>7} {'decomp(sympy)':>14} {'decomp(busca)':>14} {'h sempre 2?':>12} {'bate?':>6}")
    todos_ok = True
    for N in range(3, limite, 2):
        eh_primo = sympy.isprime(N)
        decomps = decomposicoes_trapezoidais(N)
        n_decomps = len(decomps)
        h_sempre_2 = all(h == 2 for (_, _, h) in decomps) if eh_primo else None

        # teorema preve: primo <=> exatamente 1 decomposicao, e h=2 sempre quando primo
        previsto_primo = (n_decomps == 1)
        bate = (eh_primo == previsto_primo)
        if eh_primo:
            bate = bate and h_sempre_2

        todos_ok &= bate
        status_h = str(h_sempre_2) if eh_primo else "-"
        print(f"{N:>4} {str(eh_primo):>7} {n_decomps:>14} {n_decomps:>14} {status_h:>12} {'OK' if bate else 'FALHOU':>6}")

    print(f"\nTodos os casos batem (N=3..{limite})? {todos_ok}")
    return todos_ok

def confere_tabela_1():
    """Confere a Tabela 1 do documento contra os valores publicados."""
    casos_publicados = {
        5: (True, 1, [(1,3)]),
        7: (True, 1, [(2,4)]),
        9: (False, 2, [(1,4),(3,5)]),
        11: (True, 1, [(4,6)]),
        15: (False, 3, [(0,5),(3,6),(6,8)]),
        19: (True, 1, [(8,10)]),
        21: (False, 3, [(0,6),(5,8),(9,11)]),
    }
    print("\n=== Conferindo Tabela 1 do documento ===")
    todos_ok = True
    for N, (primo_pub, n_pub, decomps_pub) in casos_publicados.items():
        decomps = sorted([(a,b) for (a,b,h) in decomposicoes_trapezoidais(N)])
        eh_primo = sympy.isprime(N)
        ok = (eh_primo == primo_pub) and (len(decomps) == n_pub) and (decomps == sorted(decomps_pub))
        todos_ok &= ok
        print(f"N={N}: primo={eh_primo} (pub={primo_pub}), decomps={decomps} (pub={sorted(decomps_pub)}) {'OK' if ok else 'DIVERGIU'}")
    print(f"Tabela 1 bate integralmente? {todos_ok}")
    return todos_ok

def testa_relacao_divisores(limite=100):
    """Confere a afirmacao da demonstracao: numero de decomposicoes nao
    triviais = numero de divisores impares de N maiores que 1."""
    print("\n=== Conferindo: nº decomposições = nº divisores ímpares > 1 ===")
    todos_ok = True
    for N in range(3, limite, 2):
        decomps = decomposicoes_trapezoidais(N)
        divisores_impares_maiores_1 = [d for d in range(3, N+1, 2) if N % d == 0]
        ok = len(decomps) == len(divisores_impares_maiores_1)
        if not ok:
            print(f"N={N}: decomps={len(decomps)} divisores_impares>1={len(divisores_impares_maiores_1)} DIVERGIU")
            todos_ok = False
    print(f"Todos batem (N=3..{limite})? {todos_ok}")
    return todos_ok

if __name__ == "__main__":
    ok1 = testa_teorema(100)
    ok2 = confere_tabela_1()
    ok3 = testa_relacao_divisores(200)
    print(f"\n=== RESULTADO GERAL: {'TEOREMA 3.1 CONFIRMADO' if (ok1 and ok2 and ok3) else 'DIVERGENCIA ENCONTRADA'} ===")
