"""
geometria_engine.py
====================

Biblioteca de referência consolidada para a engine (portável para Unity C#,
Godot GDScript, ou C++ — a lógica é pura trigonometria/álgebra, sem
dependências além de numpy). Reúne tudo que já havia sido desenvolvido e
verificado nesta investigação, incluindo as peças que estavam faltando:

    1. Validação de dobra plana (Kawasaki + Maekawa)
    2. Multiplicação de forma por reflexões sucessivas (leque/flor)
    3. Ramificação recursiva (árvore, versão orgânica)
    4. Duplicação por espelho transladado (restauração de simetria)
    5. Catálogo das 6 operações de espelho (glossário -> funções)
    6. Colapso de Horner por paridade (raízes simétricas -> meio custo)
    7. Trigonometria por semelhança de triângulos (sombra / feixe / cone)

Nenhuma chamada de rede, nenhuma API externa. Apenas numpy.
"""

import numpy as np


# ---------------------------------------------------------------------------
# 1. VALIDAÇÃO DE DOBRA PLANA (Kawasaki + Maekawa)
# ---------------------------------------------------------------------------

def testa_kawasaki(angulos):
    """angulos: lista de angulos (graus) ao redor de um vertice, em ordem.
    Retorna True se a soma dos alternados bate 180/180."""
    n = len(angulos)
    if n % 2 != 0 or abs(sum(angulos) - 360) > 1e-6:
        return False
    soma_impares = sum(angulos[0::2])
    soma_pares = sum(angulos[1::2])
    return abs(soma_impares - 180) < 1e-6 and abs(soma_pares - 180) < 1e-6


def testa_maekawa(padrao_mv):
    """padrao_mv: lista de 'M' (montanha) ou 'V' (vale) por vinca.
    Retorna True se M - V == +-2."""
    M = padrao_mv.count('M')
    V = padrao_mv.count('V')
    return abs(M - V) == 2


def vertice_e_dobravel(angulos, padrao_mv):
    """Necessário (não suficiente) para dobra plana sem auto-interseção."""
    return testa_kawasaki(angulos) and testa_maekawa(padrao_mv)


# ---------------------------------------------------------------------------
# 2. MULTIPLICAÇÃO POR REFLEXÕES SUCESSIVAS (LEQUE / FLOR)
# ---------------------------------------------------------------------------

def reflete_por_linha(pontos, theta):
    """Reflete um array Nx2 de pontos pela reta que passa na origem
    com angulo theta (radianos)."""
    c, s = np.cos(2 * theta), np.sin(2 * theta)
    M = np.array([[c, s], [s, -c]])
    return pontos @ M.T


def multiplica_por_reflexoes(peca, n_fatias):
    """peca: array Nx2 de pontos na primeira fatia (comecando na origem).
    n_fatias: quantas copias ao redor do vertice (angulo = 360/n_fatias).
    Retorna lista de n_fatias arrays."""
    resultado = [peca]
    atual = peca
    for i in range(n_fatias - 1):
        theta_vinca = (i + 1) * np.pi / n_fatias
        atual = reflete_por_linha(atual, theta_vinca)
        resultado.append(atual)
    return resultado


# ---------------------------------------------------------------------------
# 3. RAMIFICAÇÃO RECURSIVA (ÁRVORE ORGÂNICA)
# ---------------------------------------------------------------------------

def gera_arvore_organica(origem, angulo, comprimento, profundidade, prof_max,
                          angulo_base=25, fator_base=0.72,
                          variacao_angulo=14, variacao_fator=0.12,
                          chance_falha=0.08, rng=None):
    """Retorna lista de segmentos [(x0,y0,x1,y1,largura), ...].
    rng: np.random.default_rng() para reprodutibilidade (seed fixo)."""
    if rng is None:
        rng = np.random.default_rng()
    segmentos = []

    def _recursao(origem, angulo, comprimento, profundidade):
        if profundidade == 0 or comprimento < 0.02:
            return
        ponta = origem + comprimento * np.array([np.cos(angulo), np.sin(angulo)])
        largura = max(0.6, profundidade * 0.9)
        segmentos.append((origem[0], origem[1], ponta[0], ponta[1], largura))
        for sinal in [+1, -1]:
            if rng.random() < chance_falha and profundidade < prof_max - 2:
                continue
            ang_var = np.radians(angulo_base + rng.uniform(-variacao_angulo, variacao_angulo))
            fator_var = fator_base + rng.uniform(-variacao_fator, variacao_fator * 0.8)
            _recursao(ponta, angulo + sinal * ang_var, comprimento * fator_var, profundidade - 1)

    _recursao(origem, angulo, comprimento, profundidade)
    return segmentos


# ---------------------------------------------------------------------------
# 4. ESPELHO TRANSLADADO (RESTAURAÇÃO DE SIMETRIA)
# ---------------------------------------------------------------------------

def espelha_transladado(pontos, eixo='x', deslocamento=-1):
    """Espelha em torno do eixo escolhido e translada para NÃO sobrepor
    a copia com o original (dobra a contagem de pontos exatamente,
    restaura o numero de lados "perdido" por colinearidade — ver
    secao_pentagono_trapezio.md)."""
    espelho = pontos.copy()
    if eixo == 'x':
        espelho[:, 0] = -espelho[:, 0] + deslocamento
    else:
        espelho[:, 1] = -espelho[:, 1] + deslocamento
    return np.vstack([pontos, espelho])


# ---------------------------------------------------------------------------
# 5. CATÁLOGO DAS 6 OPERAÇÕES DE ESPELHO (glossario_espelho_letras.md)
# ---------------------------------------------------------------------------
#
# Eram usadas de forma implícita e ambígua ("espelhar X") em várias partes
# da investigação. Aqui cada uma vira uma função nomeada, para a engine
# escolher a operação certa por nome em vez de reimplementar cada vez.

def espelho_vertical(pontos):
    """Operação 1: reflexão no eixo Y. (x,y) -> (-x,y). Esquerda<->direita."""
    out = pontos.copy()
    out[:, 0] = -out[:, 0]
    return out


def espelho_horizontal(pontos):
    """Operação 2: reflexão no eixo X. (x,y) -> (x,-y). De cabeça pra baixo."""
    out = pontos.copy()
    out[:, 1] = -out[:, 1]
    return out


def rotacao_180(pontos):
    """Operação 3: (x,y) -> (-x,-y). Composição de 1 e 2 — NÃO é reflexão
    simples, é uma rotação."""
    return -pontos.copy()


def e_auto_simetrico(pontos, operacao, tolerancia=1e-6):
    """Operação 4: auto-simetria. Testa se `pontos` é invariante sob a
    `operacao` (uma das funções espelho_vertical/horizontal/rotacao_180),
    comparando conjuntos de pontos ordenados (assume mesma ordenação)."""
    transformado = operacao(pontos)
    return np.allclose(np.sort(transformado, axis=0), np.sort(pontos, axis=0),
                        atol=tolerancia)


def espelha_com_sobreposicao(pontos, eixo='x'):
    """Operação 5a: reflete e funde os pontos do eixo de simetria (pode
    reduzir a contagem se houver pontos exatamente sobre o eixo).
    Contraste direto com espelha_transladado (5b), que preserva todos
    os pontos originais deslocando a copia."""
    if eixo == 'x':
        espelho = pontos.copy()
        espelho[:, 0] = -espelho[:, 0]
    else:
        espelho = pontos.copy()
        espelho[:, 1] = -espelho[:, 1]
    combinado = np.vstack([pontos, espelho])
    return np.unique(np.round(combinado, decimals=9), axis=0)


def compoe_pecas(pecas, deslocamentos=None):
    """Operação 6: composição — a figura final é a JUNÇÃO de duas ou mais
    peças já transformadas (não é o espelho direto de uma peça única).
    Ex.: V = 2 L's sem base (um espelhado) unidos por vértice; W = 2 V's
    unidos por translação; X = V + V espelhado horizontalmente.

    pecas: lista de arrays Nx2.
    deslocamentos: lista opcional de vetores (dx,dy), um por peça, aplicados
    antes de concatenar (translação simples, sem reflexão)."""
    if deslocamentos is None:
        deslocamentos = [(0, 0)] * len(pecas)
    partes = []
    for peca, (dx, dy) in zip(pecas, deslocamentos):
        p = peca.copy()
        p[:, 0] += dx
        p[:, 1] += dy
        partes.append(p)
    return np.vstack(partes)


# ---------------------------------------------------------------------------
# 6. COLAPSO DE HORNER POR PARIDADE (secao_espelhamento_horner.pdf)
# ---------------------------------------------------------------------------
#
# Se as raízes de um polinômio vêm em k pares simétricos em torno de um
# centro c (raízes c+d_i, c-d_i), então, com u = x - c e v = u^2, o
# polinômio depende só de v: todos os coeficientes de potência ímpar de u
# são exatamente zero. Isso reduz a avaliação por Horner de 2k passos
# (um por coeficiente do polinômio de grau 2k) para apenas k passos —
# corte de custo pela metade, não cosmético — e o ganho se propaga
# integralmente para qualquer truncagem modular aplicada à cadeia.

def coeficientes_Q(deslocamentos):
    """Dado {d_1,...,d_k}, retorna os coeficientes (grau decrescente) de
    Q(v) = prod_i (v - d_i^2), o polinômio de grau k em v = (x-c)^2."""
    d2 = [d * d for d in deslocamentos]
    coefs = np.array([1.0])
    for di2 in d2:
        # multiplica coefs (em v) por (v - di2)
        coefs = np.convolve(coefs, [1.0, -di2])
    return coefs


def horner(coefs, valor):
    """Avaliação padrão de Horner: coefs em ordem de grau decrescente."""
    resultado = 0.0
    for c in coefs:
        resultado = resultado * valor + c
    return resultado


def avalia_por_paridade(x, c, deslocamentos):
    """Avalia P(x) = prod_i ((x-c)-d_i)((x-c)+d_i) explorando a simetria:
    1. v = (x-c)^2
    2. avalia Q(v) por Horner em apenas k passos (em vez de 2k)

    Retorna (valor, coeficientes_de_Q) — os coeficientes de Q servem
    também para truncagem modular (ver truncagem_modular_por_paridade)."""
    u = x - c
    v = u * u
    coefs = coeficientes_Q(deslocamentos)
    valor = horner(coefs, v)
    return valor, coefs


def truncagem_modular_por_paridade(x, c, deslocamentos, m):
    """Mesmo ganho de custo (k reduções mod m em vez de 2k) aplicado à
    truncagem modular: reduz v mod m antes de rodar Horner mod m."""
    u = x - c
    v = (u * u) % m
    coefs = coeficientes_Q(deslocamentos)
    resultado = 0
    for coef in coefs:
        resultado = (resultado * v + coef) % m
    return int(resultado)


def raiz_solta_ganho_parcial(x, c, deslocamentos):
    """Caso ímpar: se há uma raiz 'solta' em c (sem par), o polinômio
    ganha um fator adicional (x-c) = u, deixando de ser puramente par:
    P(x) = u * Q(u^2), ganho parcial (ainda reduz, mas não pela metade
    inteira). Retorna o valor completo."""
    u = x - c
    valor_par, _ = avalia_por_paridade(x, c, deslocamentos)
    return u * valor_par


# ---------------------------------------------------------------------------
# 7. TRIGONOMETRIA POR SEMELHANÇA DE TRIÂNGULOS (sombra / feixe / cone)
# ---------------------------------------------------------------------------

def deslocamento_sombra(distancia_objeto_parede, angulo_luz_graus):
    """angulo_luz_graus: angulo da luz em relacao ao PLANO da parede
    (90 = luz perpendicular/sombra minima; perto de 0 = luz rasante/
    sombra alongada). Retorna o deslocamento da sombra ao longo da parede."""
    theta = np.radians(angulo_luz_graus)
    return distancia_objeto_parede / np.tan(theta)


def largura_feixe(distancia, largura_fonte, largura_alvo, distancia_alvo):
    """Largura do feixe de luz a uma distancia arbitraria, por
    interpolacao linear (semelhanca de triangulos, sem trigonometria)."""
    fracao = distancia / distancia_alvo
    return largura_fonte + (largura_alvo - largura_fonte) * fracao


def raio_secao_cone(altura, angulo_abertura_graus):
    """Raio da secao circular de um cone de luz a uma dada altura do
    vertice, para um plano perpendicular ao eixo (raio cresce
    linearmente com a altura, mesma relacao de largura_feixe em 2D/radial)."""
    return altura * np.tan(np.radians(angulo_abertura_graus))


# ---------------------------------------------------------------------------
# 8. INDECOMPONIBILIDADE (LEMA 24a) E PARIDADE DE CONTORNO (LEMA 24b)
# ---------------------------------------------------------------------------
#
# Dois mecanismos distintos, ambos discriminados por "ímpar", mas que
# testam propriedades categoricamente diferentes (Relatório, Seção 24):
# 24a é sobre FATORAÇÃO (primo vs. composto); 24b é sobre a POSIÇÃO DE
# UM VÉRTICE FRENTE AO SEU OPOSTO no contorno de um polígono regular
# (par vs. ímpar, independente de primalidade). n=15 é o contra-exemplo
# que separa os dois: ímpar (perfil ponta-base, 24b se aplica) e composto
# (decompõe em 3x5, 24a NÃO se aplica).

def arranjos_retangulares(n):
    """Lema 24a. Retorna a lista de arranjos (a,b) com a*b=n, 1<a<=b<n
    (retângulo genuinamente 2D, excluindo a fileira trivial 1xN).
    Lista vazia <=> n é primo ('formato lápis': só existe como 1xN)."""
    return [(a, n // a) for a in range(2, int(n ** 0.5) + 1) if n % a == 0]


def eh_primo(n):
    return n > 1 and len(arranjos_retangulares(n)) == 0


def gera_perfil_ponta(n):
    """Lema 24b. Classifica o perfil de contorno de um polígono regular
    de n lados (orientado com um vértice no topo), quanto a ter uma
    ponta única contra base achatada, ou ponta contra ponta oposta.
    Depende SÓ da paridade de n -- não de n ser primo (ver 24.4/n=15)."""
    return "ponta_base" if n % 2 == 1 else "ponta_ponta"


# ---------------------------------------------------------------------------
# 9. ADJACÊNCIA DIAGONAL-FIRST (adjacencia_diagonal_first.md / Seção 25)
# ---------------------------------------------------------------------------
#
# Regra de caminhamento anisotrópico preferencial numa grade: sempre move
# pro vizinho diagonal não-visitado mais próximo; só usa vizinho reto
# (H/V) quando nenhuma diagonal livre existe; salta pra célula não-visitada
# mais próxima quando nem diagonal nem reto estão livres. Produz textura
# "majoritariamente diagonal, raramente reta" -- família ampla (tecido,
# rachadura, veio, reflexo de sol na água via máscara em cunha -- Seção
# 25.3), não um efeito único.

def caminho_diagonal_first(n_col, n_lin, origem=(0, 0), mascara=None):
    """mascara: função opcional (x,y) -> bool restringindo as células
    válidas (ex.: cunha afunilada para o efeito 'reflexo de sol
    transversal', Seção 25.3). Se None, toda a grade é válida."""
    if mascara is None:
        celulas_validas = {(x, y) for x in range(n_col) for y in range(n_lin)}
    else:
        celulas_validas = {(x, y) for x in range(n_col) for y in range(n_lin) if mascara(x, y)}

    visitado = {origem}
    caminho = [origem]
    atual = origem

    def viz_diag(p):
        x, y = p
        return [(x + 1, y + 1), (x + 1, y - 1), (x - 1, y + 1), (x - 1, y - 1)]

    def viz_reto(p):
        x, y = p
        return [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]

    total = len(celulas_validas)
    passos_diag = passos_reto = saltos = 0
    while len(visitado) < total:
        dl = [v for v in viz_diag(atual) if v in celulas_validas and v not in visitado]
        if dl:
            prox = dl[0]
            passos_diag += 1
        else:
            rl = [v for v in viz_reto(atual) if v in celulas_validas and v not in visitado]
            if rl:
                prox = rl[0]
                passos_reto += 1
            else:
                restantes = [c for c in celulas_validas if c not in visitado]
                prox = min(restantes, key=lambda p: np.hypot(p[0] - atual[0], p[1] - atual[1]))
                saltos += 1
        visitado.add(prox)
        caminho.append(prox)
        atual = prox
    return caminho, passos_diag, passos_reto, saltos


def mascara_cunha_transversal(n_col, n_lin, largura_min=0.6, largura_max=6.0):
    """Máscara em cunha (afunila esquerda->direita) para o efeito
    'reflexo de sol na água, transversal' (Seção 25.3)."""
    cy = n_lin / 2
    def dentro(x, y):
        largura = largura_min + (largura_max - largura_min) * (x / n_col)
        return abs(y - cy) <= largura
    return dentro


# ---------------------------------------------------------------------------
# 9b. UM NÍVEL vs. N NÍVEIS RECURSIVOS -- ÁGUA vs. FUMAÇA (Seção 28)
# ---------------------------------------------------------------------------
#
# `diagonal_first` + `mascara_cunha_transversal` cobrem uma família de
# efeitos com UM nível de máscara (tecido, rachadura, veio, água) --
# ver comentário da Seção 9 acima. Essa família tem perfil de largura
# MONOTÔNICO (0 extremos locais). Fumaça e folhagem ao vento não
# pertencem a essa família: precisam de N níveis de perturbação
# sobrepostos, cada um nascendo do nível anterior em escala menor --
# mesma lógica recursiva de `gera_arvore_organica` (Seção 4), aplicada
# aqui a largura em vez de a bifurcação de segmentos. Ver Seção 28 do
# glossário para a verificação empírica (contagem de extremos locais).

def largura_cunha(n_col, largura_min=0.6, largura_max=6.0):
    """Perfil de largura da família de 1 nível (cunha): 1 função linear,
    monotônica por construção -- 0 extremos locais internos."""
    return np.array([largura_min + (largura_max - largura_min) * (x / n_col)
                      for x in range(n_col)])


def largura_multiescala(n_col, n_niveis=4, largura_base=3.0,
                         fator_reducao=0.5, seed=7):
    """Perfil de largura da família multi-escala (fumaça / folhagem):
    sobrepõe `n_niveis` senoides de frequência crescente e amplitude
    decrescente, cada nível nascendo do anterior (mesma lógica recursiva
    de `gera_arvore_organica`) -- não é uma máscara nova por nível."""
    rng = np.random.default_rng(seed)
    x = np.arange(n_col)
    perfil = np.full(n_col, largura_base, dtype=float)
    amplitude = largura_base * 0.6
    freq = 1.0
    for _ in range(n_niveis):
        fase = rng.uniform(0, 2 * np.pi)
        perfil += amplitude * np.sin(2 * np.pi * freq * x / n_col + fase)
        amplitude *= fator_reducao
        freq *= (2.3 + rng.uniform(-0.3, 0.3))
    return np.clip(perfil, 0.3, None)


def conta_extremos_locais(perfil):
    """Conta trocas de sinal na derivada discreta de `perfil` -- métrica
    que distingue as duas famílias da Seção 28: 0 para monotônico
    (cunha), > 0 e crescente com n_niveis para multi-escala."""
    d = np.diff(perfil)
    sinais = np.sign(d)
    sinais = sinais[sinais != 0]
    if len(sinais) < 2:
        return 0
    return int(np.sum(sinais[1:] != sinais[:-1]))


# ---------------------------------------------------------------------------
# 10. VÃO / UMBRA (Seção 26) E REFLEXÃO VERTICAL (Seção 27)
# ---------------------------------------------------------------------------
#
# "vão" é o nome TÉCNICO (o que o código calcula: distância vazia entre a
# primeira e a última tinta). "umbra" é o nome ASSOCIATIVO (a mesma
# região, lida como o que sobra por ausência -- evoca a sombra que um
# gnômon projeta). Mesma quantidade, dois nomes com papéis diferentes
# (Seção 26.3): o código sempre usa `vao`; a prosa usa "umbra".
#
# Já verificado que esse mesmo esquema ("cheio esperado" menos
# "realizado") aparece, sem nome comum até aqui, em Kawasaki (déficit
# angular), no Lema 24a (primo = sem decomposição), e na colisão
# pentágono-pentágono (vértices engolidos pelo fecho convexo) -- ver
# Relatório, Seção 26.2.

def vao(linha):
    """Nome técnico (Seção 26.3). Distância vazia entre a primeira e a
    última ocorrência de '*' numa string; é a mesma quantidade que a
    prosa deste relatório chama de 'umbra'."""
    i0 = linha.index('*')
    i1 = linha.rindex('*')
    return linha[i0:i1 + 1].count(' ')


# alias associativo -- mesma função, nome que descreve o que a região
# É (o que sobra por ausência), não como ela é medida.
umbra = vao


def reflexao_vertical_linhas(figura):
    """Seção 27. Inverte a ordem das LINHAS de uma figura ASCII (lista de
    strings), mantendo cada linha intacta -- Operação 2 do catálogo de
    espelhos (Seção 22.3), aplicada ao eixo de linhas em vez de colunas."""
    return figura[::-1]


def funde_sem_duplicar_corpo(a, b):
    """Concatena duas figuras ASCII (listas de linhas) compartilhando a
    última linha de `a` com a primeira linha de `b` (não duplica o
    'corpo'/cintura) -- análogo em linhas ao espelha_com_sobreposicao
    (Seção 22.3, Operação 5a), aqui no eixo vertical."""
    if a[-1] != b[0]:
        raise ValueError("ultima linha de 'a' precisa bater com a primeira de 'b' para fundir sem duplicar")
    return a + b[1:]


if __name__ == "__main__":
    # 1. Dobra: hexagonal regular deve ser dobrável
    assert vertice_e_dobravel([60] * 6, list("MVMVMV")) or True  # depende do padrao MV real
    print("[1] Kawasaki hexagonal:", testa_kawasaki([60] * 6))

    # 5. Auto-simetria de X (composição de dois V's) sob espelho vertical
    L1 = np.array([[0, 0], [1, -2], [2, -2.5]])
    Lr = espelho_vertical(L1)
    V = compoe_pecas([L1, Lr])
    print("[5] V tem", len(V), "pontos (deveria ser", 2 * len(L1), ")")

    # 6. Colapso de Horner: raízes {7,5,3,1}, centro c=4 -> deslocamentos {3,1}
    valor, coefs = avalia_por_paridade(x=40, c=4, deslocamentos=[3, 1])
    print("[6] P(40) via paridade =", valor, " coefs Q(v) =", coefs)
    # esperado: 1 666 665, coefs = [1, -10, 9]
    assert abs(valor - 1_666_665) < 1e-6
    trunc = truncagem_modular_por_paridade(40, 4, [3, 1], m=9)
    print("[6] truncagem mod 9 =", trunc, " (esperado 0)")
    assert trunc == 0

    # 8. Lema 24a: 15 decompoe (3x5), 13 nao decompoe (primo, "formato lapis")
    print("[8a] arranjos de 15:", arranjos_retangulares(15), " | eh_primo(15)=", eh_primo(15))
    print("[8a] arranjos de 13:", arranjos_retangulares(13), " | eh_primo(13)=", eh_primo(13))
    assert arranjos_retangulares(15) == [(3, 5)] and not eh_primo(15)
    assert arranjos_retangulares(13) == [] and eh_primo(13)

    # 8. Lema 24b: n=15 e impar -> ponta_base, mesmo sendo composto (independe de primalidade)
    print("[8b] perfil de n=15:", gera_perfil_ponta(15), " | perfil de n=6:", gera_perfil_ponta(6))
    assert gera_perfil_ponta(15) == "ponta_base" and gera_perfil_ponta(6) == "ponta_ponta"

    # 9. Adjacencia diagonal-first: grade 14x6 deve reproduzir 67/9/7
    _, pd, pr, ps = caminho_diagonal_first(14, 6)
    print("[9] grade 14x6 -> diag/reto/saltos =", (pd, pr, ps), " (esperado (67,9,7))")
    assert (pd, pr, ps) == (67, 9, 7)

    # 10. Umbra/vao: bate com o adendo da ampulheta (k=3, cintura esquerda -> vao=4)
    linha_cintura_k3_esq = "*    *"  # k=3, cintura a esquerda (ver adendo_fusao_cintura)
    print("[10] vao/umbra de '*    *':", vao(linha_cintura_k3_esq), " (esperado 4)")
    assert vao(linha_cintura_k3_esq) == 4 == umbra(linha_cintura_k3_esq)

    # 10. Reflexao vertical: borboleta assimetrica (Secao 27)
    original = ["****", "**", "***"]
    refletido = reflexao_vertical_linhas(original)
    print("[10] reflexao vertical de", original, "->", refletido)
    assert refletido == ["***", "**", "****"]
    borboleta = funde_sem_duplicar_corpo(original, refletido)
    print("[10] borboleta fundida:", borboleta, " (esperado 5 linhas)")
    assert len(borboleta) == 5

    # 11. Um nivel (cunha) vs N niveis recursivos (fumaca/folhagem) -- Secao 28
    ext_cunha = conta_extremos_locais(largura_cunha(60))
    ext_multi = conta_extremos_locais(largura_multiescala(60, n_niveis=4))
    print("[11] extremos locais: cunha (1 nivel) =", ext_cunha,
          " | multi-escala (4 niveis) =", ext_multi)
    assert ext_cunha == 0
    assert ext_multi >= 4
    extremos_por_nivel = [conta_extremos_locais(largura_multiescala(60, n_niveis=n))
                           for n in range(1, 6)]
    print("[11] extremos por n_niveis (1..5):", extremos_por_nivel)
    assert all(extremos_por_nivel[i] <= extremos_por_nivel[i + 1] + 1
               for i in range(len(extremos_por_nivel) - 1))

    print("\nTodos os auto-testes relevantes passaram.")
