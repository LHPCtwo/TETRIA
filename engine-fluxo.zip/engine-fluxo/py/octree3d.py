"""
Octree 3D genérico + geradores de dados sintéticos que reproduzem
características estruturais de dados reais de ocupação esparsa:

  - esfera dentro de um cubo LxLxL   -> proxy de órgão/tumor (volume médico)
  - heightmap suave (ruído coerente)  -> proxy de terreno voxel de jogo
  - ruído puro (sem estrutura)        -> limite inferior de compressibilidade

Comparamos a razão nós/células com a obtida na construção algébrica
pura do relatório (malha triangular / hexágono, O(L) em 2D).
"""

import random
from dataclasses import dataclass
from typing import Optional, Callable


@dataclass
class OctNode:
    x0: int; y0: int; z0: int; size: int
    value: Optional[int] = None
    children: Optional[list] = None


def region_value_3d(occ, x0, y0, z0, size):
    """Homogeneidade por amostragem: 8 cantos + centro; exato para size<=2."""
    pts = [
        (x0, y0, z0), (x0+size-1, y0, z0), (x0, y0+size-1, z0), (x0, y0, z0+size-1),
        (x0+size-1, y0+size-1, z0), (x0+size-1, y0, z0+size-1), (x0, y0+size-1, z0+size-1),
        (x0+size-1, y0+size-1, z0+size-1),
        (x0+size//2, y0+size//2, z0+size//2),
    ]
    vals = [occ(*p) for p in pts]
    if len(set(vals)) != 1:
        return None
    if size <= 2:
        vals_exatos = [occ(x,y,z) for x in range(x0,x0+size) for y in range(y0,y0+size) for z in range(z0,z0+size)]
        if len(set(vals_exatos)) != 1:
            return None
        return vals_exatos[0]
    return vals[0]


def build_octree(occ, x0, y0, z0, size):
    v = region_value_3d(occ, x0, y0, z0, size)
    if v is not None:
        return OctNode(x0, y0, z0, size, value=v)
    h = size // 2
    children = []
    for dx in (0, h):
        for dy in (0, h):
            for dz in (0, h):
                children.append(build_octree(occ, x0+dx, y0+dy, z0+dz, h))
    return OctNode(x0, y0, z0, size, children=children)


def count_nodes(node):
    if node.children is None:
        return 1
    return 1 + sum(count_nodes(c) for c in node.children)


# ---------------------------------------------------------------------
# geradores de ocupação sintética
# ---------------------------------------------------------------------

def make_sphere_occ(L, raio_frac=0.35):
    cx = cy = cz = L / 2.0
    r2 = (L * raio_frac) ** 2
    def occ(x, y, z):
        d2 = (x - cx)**2 + (y - cy)**2 + (z - cz)**2
        return 1 if d2 <= r2 else 0
    return occ


def make_terrain_occ(L, seed=0, escala=4):
    """Heightmap suave: soma de senoides com fases aleatorias (ruido coerente barato,
    sem depender de bibliotecas externas de Perlin noise)."""
    random.seed(seed)
    termos = [(random.uniform(0.5, 2.0), random.uniform(0, 6.28), random.randint(1, 4)) for _ in range(4)]
    def altura(x, y):
        import math
        v = 0.0
        for amp, fase, freq in termos:
            v += amp * math.sin(freq * x / L * 6.28 + fase) * math.cos(freq * y / L * 6.28 + fase)
        v = (v + 4) / 8.0  # normaliza aproximadamente para [0,1]
        return max(0.0, min(1.0, v)) * (L * 0.7)
    def occ(x, y, z):
        return 1 if z < altura(x, y) else 0
    return occ


def make_noise_occ(L, p=0.5, seed=0):
    random.seed(seed)
    cache = {}
    def occ(x, y, z):
        key = (x, y, z)
        if key not in cache:
            cache[key] = 1 if random.random() < p else 0
        return cache[key]
    return occ
