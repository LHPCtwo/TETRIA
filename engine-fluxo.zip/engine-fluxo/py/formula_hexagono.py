def pontos_hexagono_real(L, k):
    C = L - 1
    trap1 = [(x, y) for y in range(L) for x in range(L - y) if x + y >= k]
    def reflete(p, C):
        x, y = p
        return (C - y, C - x)
    trap2 = [reflete(p, C) for p in trap1]
    unicos = set(trap1) | set(trap2)
    return len(unicos)

def formula(L, k):
    return L*L - k*(k+1)

print(f"{'L':>4} {'k':>4} {'real':>8} {'formula L²-k(k+1)':>20} {'bate?':>6}")
todos_ok = True
for L in [5, 9, 12, 20, 50, 100]:
    for k in [1, 2, 3, L//4, L//3, L//2-1]:
        if k < 1 or k >= L: continue
        real = pontos_hexagono_real(L, k)
        f = formula(L, k)
        ok = real == f
        todos_ok &= ok
        print(f"{L:>4} {k:>4} {real:>8} {f:>20} {'sim' if ok else 'NAO':>6}")

print(f"\ntodos os casos bateram? {todos_ok}")
