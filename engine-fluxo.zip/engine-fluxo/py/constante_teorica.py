"""
Para dados verdadeiramente aleatorios (p=0.5, i.i.d.), se NUNCA houver
homogeneidade real em regioes de tamanho > 1 (o que e quase certo pra
p=0.5 com celulas independentes), a arvore sempre subdivide ate folhas
1x1x1. Nesse caso o numero total de nos e a soma geometrica de todos os
niveis:

  N = 1 + b + b^2 + ... + b^d   onde b = fator de ramificacao (4 p/ quadtree, 8 p/ octree)
                                       b^d = numero de celulas brutas (raw)

  N/raw = (b^(d+1) - 1) / (b-1) / b^d  --> b/(b-1) quando d cresce

  quadtree (2D, b=4): 4/3 = 1.3333...
  octree   (3D, b=8): 8/7 = 1.142857...

O valor medido (1.123, L=64) usa uma HEURISTICA de amostragem (cantos+
centro, 9 pontos) em vez de checar todas as celulas -- isso permite
"falsos positivos" de homogeneidade (9 amostras baterem por acaso: 
probabilidade (1/2)^8 = 1/256 por no testado), parando a subdivisao
mais cedo que o teste exato e reduzindo o numero de nos abaixo de b/(b-1).

Vamos comparar heuristica vs teste EXATO (todas as celulas) para
confirmar a convergencia teorica.
"""
import random

def build_octree_exato(occ_dict, x0, y0, z0, size):
    """Teste de homogeneidade EXATO: verifica todas as size^3 celulas."""
    vals = set()
    for x in range(x0, x0+size):
        for y in range(y0, y0+size):
            for z in range(z0, z0+size):
                vals.add(occ_dict[(x,y,z)])
                if len(vals) > 1:
                    break
            if len(vals) > 1: break
        if len(vals) > 1: break
    if len(vals) == 1:
        return 1  # folha homogenea, 1 no
    if size == 1:
        return 1
    h = size // 2
    total = 1  # este no interno
    for dx in (0,h):
        for dy in (0,h):
            for dz in (0,h):
                total += build_octree_exato(occ_dict, x0+dx, y0+dy, z0+dz, h)
    return total

random.seed(42)
for L in [8, 16, 32]:
    occ = {(x,y,z): random.randint(0,1) for x in range(L) for y in range(L) for z in range(L)}
    n = build_octree_exato(occ, 0,0,0, L)
    raw = L**3
    print(f"L={L:>3}  raw={raw:>7,}  nos(exato)={n:>7,}  razao={n/raw:.6f}  teorico(8/7)={8/7:.6f}")
