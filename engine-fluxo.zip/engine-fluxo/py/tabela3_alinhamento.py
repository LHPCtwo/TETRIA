"""
Reproduz a Tabela 3 do relatório (Secao 9: "A constante da Tabela 1 nao e
universal: sensibilidade ao alinhamento binario").

Reusa o mesmo quadtree e o mesmo occ() de compress_demo-3.py -- nao
reimplementa nada, so varia k/L para L=4096 fixo e mede nos/L.
"""

import importlib.util
import os

_here = os.path.dirname(os.path.abspath(__file__))
_spec = importlib.util.spec_from_file_location("cd", os.path.join(_here, "compress_demo-3.py"))
cd = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(cd)


def nodes_per_L(L: int, frac_k_over_L: float):
    k = int(L * frac_k_over_L)
    if k < 1:
        k = 1
    c = (L - k) // 2

    size = 1
    while size < L:
        size *= 2

    occ = cd.make_occ(L, k, c)
    tree = cd.build_quadtree(occ, 0, 0, size)
    n = cd.count_nodes(tree)
    return k, n, n / L


def demo_tabela3(L: int = 4096):
    fracoes = [
        ("1/4", 1 / 4),
        ("1/6", 1 / 6),
        ("1/3", 1 / 3),
        ("3/8", 3 / 8),
        ("1/2", 1 / 2),
        ("5/8", 5 / 8),
    ]
    print(f"--- Tabela 3: L={L} fixo, k/L variando ---")
    print(f"{'k/L':>6} {'k':>8} {'nos':>10} {'nos/L':>8}")
    resultados = []
    for label, frac in fracoes:
        k, n, ratio = nodes_per_L(L, frac)
        print(f"{label:>6} {k:>8} {n:>10,} {ratio:>8.2f}")
        resultados.append((label, ratio))
    return resultados


def demo_tabela1_sanity(L_values=(16, 64, 256, 1024, 4096)):
    """Sanity check: reconfirma a Tabela 1 (k ~ L/3) usando a mesma funcao,
    para garantir que nodes_per_L nao diverge da implementacao original."""
    print(f"\n--- Sanity check contra Tabela 1 (k ~ L/3) ---")
    print(f"{'L':>6} {'k':>8} {'nos':>10} {'nos/L':>8}")
    for L in L_values:
        k, n, ratio = nodes_per_L(L, 1 / 3)
        print(f"{L:>6} {k:>8} {n:>10,} {ratio:>8.2f}")


ESPERADO_TABELA3 = {
    "1/4": 4.00,
    "1/6": 5.32,
    "1/3": 6.66,
    "3/8": 4.01,
    "1/2": 4.00,
    "5/8": 4.01,
}


def valida_contra_relatorio(tolerancia: float = 0.05):
    """Compara o resultado medido contra os valores publicados na Tabela 3
    (tolerancia absoluta em nos/L, ja que o relatorio arredonda em 2 casas)."""
    resultados = demo_tabela3()
    print("\n--- Validacao contra valores publicados ---")
    ok = True
    for label, ratio in resultados:
        esperado = ESPERADO_TABELA3[label]
        diff = abs(ratio - esperado)
        status = "OK" if diff <= tolerancia else "DIVERGIU"
        if status != "OK":
            ok = False
        print(f"  k/L={label:>4}: medido={ratio:.2f}  esperado={esperado:.2f}  "
              f"diff={diff:.3f}  [{status}]")
    print(f"\nResultado geral: {'TODOS OK' if ok else 'HA DIVERGENCIA'}")
    return ok


if __name__ == "__main__":
    valida_contra_relatorio()
    demo_tabela1_sanity()
