from octree3d import build_octree, count_nodes, make_sphere_occ, make_terrain_occ, make_noise_occ

print("RESUMO COMPARATIVO")
print(f"{'construção':>20} {'dimensão':>9} {'raw':>7} {'compressão':>10} {'razão (nós/raw)':>16}")

# algebrica: pega da formula do relatorio, L=128 k=43 (k~L/3)
L=128; k=L//3
raw2d = L*L
nos2d_estim = int(6.6*L)  # da tabela do relatorio, constante ~6.6
print(f"{'algébrica (2D, malha)':>20} {'2D':>9} {raw2d:>7,} {'O(L)':>10} {nos2d_estim/raw2d:>16.5f}")

for nome, factory in [("esfera (médico)", make_sphere_occ), ("terreno (jogo)", make_terrain_occ)]:
    t = build_octree(factory(L), 0,0,0, L)
    n = count_nodes(t)
    raw3d = L**3
    print(f"{nome:>20} {'3D':>9} {raw3d:>7,} {'O(L²)':>10} {n/raw3d:>16.5f}")

t = build_octree(make_noise_occ(64), 0,0,0, 64)
n = count_nodes(t)
raw3d = 64**3
print(f"{'ruído puro':>20} {'3D':>9} {raw3d:>7,} {'O(L³)':>10} {n/raw3d:>16.5f}  <- PIOR que armazenar cru")
