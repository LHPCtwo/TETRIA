import time
from octree3d import build_octree, make_sphere_occ, make_terrain_occ

def render_denso(occ, L):
    buffer = [[[0]*L for _ in range(L)] for _ in range(L)]
    for z in range(L):
        for y in range(L):
            for x in range(L):
                buffer[z][y][x] = occ(x, y, z)
    return buffer

def render_arvore(node):
    if node.children is None:
        return 1
    return 1 + sum(render_arvore(c) for c in node.children)

def compara(nome, occ_factory, L, n_frames=10):
    occ = occ_factory(L)

    # custo de construir a arvore UMA VEZ (analogo a carregar o asset)
    t0 = time.time()
    tree = build_octree(occ, 0, 0, 0, L)
    t_build = time.time() - t0

    # custo de renderizar N "frames" a partir da estrutura ja pronta
    t0 = time.time()
    for _ in range(n_frames):
        render_arvore(tree)
    t_render_arvore_total = time.time() - t0

    # array denso: cada frame reconstroi/varre tudo de novo (sem estrutura persistente)
    t0 = time.time()
    for _ in range(n_frames):
        render_denso(occ, L)
    t_render_denso_total = time.time() - t0

    print(f"--- {nome}, L={L}, {n_frames} frames ---")
    print(f"  build da árvore (1x, custo fixo):     {t_build*1000:>8.1f} ms")
    print(f"  {n_frames} frames array denso:              {t_render_denso_total*1000:>8.1f} ms  ({t_render_denso_total/n_frames*1000:.2f} ms/frame)")
    print(f"  {n_frames} frames árvore (já construída):    {t_render_arvore_total*1000:>8.1f} ms  ({t_render_arvore_total/n_frames*1000:.2f} ms/frame)")
    print(f"  ganho por frame (após 1x build): {t_render_denso_total/t_render_arvore_total:.1f}x mais rápido")
    total_arvore = t_build + t_render_arvore_total
    total_denso = t_render_denso_total
    print(f"  total ({n_frames} frames + build): árvore={total_arvore*1000:.1f}ms vs denso={total_denso*1000:.1f}ms -> {'árvore vence' if total_arvore<total_denso else 'denso vence'}")
    print()

for L in [32, 64]:
    compara("esfera", make_sphere_occ, L, n_frames=20)
    compara("terreno", make_terrain_occ, L, n_frames=20)
