"""
Gera um arquivo binário world.stream: um asset real em disco para o
SliceStreamer da engine ler, em vez da malha hardcoded em memória.

Formato (little-endian, tudo int32 = 4 bytes):

  header:  MAGIC (4 bytes ASCII "WFLX") | L (int32) | num_slices (int32)
  por fatia (num_slices vezes):  k (int32) | c (int32)

Réplica do streaming 3D da Seção 5 (demo_3d_streaming em
compress_demo-3.py): para z < k_max, a fatia tem bloco central de lado
k(z) decrescente (como um paraboloide/cone extrudado); para z >= k_max,
k=0 (só a malha triangular, sem bloco).

Isso é dado real gravado em disco, que o SliceStreamer vai abrir com
std::ifstream, dar seek pela posição z e ler -- não é mais um valor
fixo em memória.
"""
import struct
import sys

MAGIC = b"WFLX"


def gera_world_stream(path: str, L: int, num_slices: int, k_max: int):
    with open(path, "wb") as f:
        f.write(MAGIC)
        f.write(struct.pack("<i", L))
        f.write(struct.pack("<i", num_slices))
        for z in range(num_slices):
            if z < k_max:
                # bloco encolhe conforme z aumenta (como um cone extrudado)
                k = k_max - z
            else:
                k = 0
            c = (L - k) // 2 if k > 0 else 0
            f.write(struct.pack("<i", k))
            f.write(struct.pack("<i", c))
    print(f"Gravado {path}: L={L}, {num_slices} fatias, k_max={k_max}")


def le_world_stream(path: str):
    """Leitura de verificação (espelha o que o SliceStreamer em C++ vai fazer)."""
    with open(path, "rb") as f:
        magic = f.read(4)
        assert magic == MAGIC, f"magic invalido: {magic}"
        L, num_slices = struct.unpack("<ii", f.read(8))
        fatias = []
        for _ in range(num_slices):
            k, c = struct.unpack("<ii", f.read(8))
            fatias.append((k, c))
    return L, num_slices, fatias


if __name__ == "__main__":
    path = sys.argv[1] if len(sys.argv) > 1 else "world.stream"
    L = 256
    num_slices = 256
    k_max = 85
    gera_world_stream(path, L, num_slices, k_max)

    # verificacao
    L2, n2, fatias = le_world_stream(path)
    assert L2 == L and n2 == num_slices
    assert fatias[0] == (k_max, (L - k_max) // 2)
    assert fatias[k_max] == (0, 0)  # primeira fatia sem bloco
    assert fatias[-1] == (0, 0)
    print(f"Verificacao OK: {len(fatias)} fatias lidas, primeira={fatias[0]}, "
          f"na transicao(z={k_max})={fatias[k_max]}, ultima={fatias[-1]}")
