"""
Verifica as novas seções do documento estendido:
- Proposição 6.2: hexágono de raio k tem 6k² triângulos elementares
- Contagem de losangos (máximo teórico 3k²) e hexágonos menores (H(k-1))
- Seção 8: cubo em 3 losangos (ilusão de Necker), octaedro em 6 triângulos,
  soma de ângulos 3×120°=360°
"""
import numpy as np
from itertools import product

def gera_malha_hexagonal(k):
    """Gera os pontos da malha triangular dentro de um hexágono de raio k
    (coordenadas axiais de grade hexagonal, padrão para hex grids)."""
    pontos = []
    for q in range(-k, k+1):
        for r in range(-k, k+1):
            s = -q - r
            if max(abs(q), abs(r), abs(s)) <= k:
                pontos.append((q, r))
    return pontos

def axial_para_cartesiano(q, r):
    x = q + r/2
    y = r * np.sqrt(3)/2
    return (x, y)

def H(k):
    return 3*k*k + 3*k + 1

def testa_H_k(limite=6):
    print("=== H(k) = numero de pontos no hexagono de raio k ===")
    ok = True
    for k in range(limite):
        pontos = gera_malha_hexagonal(k)
        esperado = H(k)
        bate = len(pontos) == esperado
        ok &= bate
        print(f"k={k}: pontos gerados={len(pontos)} H(k)={esperado} {'OK' if bate else 'DIVERGIU'}")
    return ok

def conta_triangulos_delaunay(k):
    """Conta triangulos elementares (area unitaria equilatera) via Delaunay,
    igual o documento descreve."""
    from scipy.spatial import Delaunay
    pontos_axiais = gera_malha_hexagonal(k)
    pontos_cart = np.array([axial_para_cartesiano(q,r) for (q,r) in pontos_axiais])
    tri = Delaunay(pontos_cart)
    # filtra so triangulos de area ~ (sqrt(3)/4) (area do triangulo unitario equilatero)
    area_esperada = np.sqrt(3)/4
    count = 0
    for simplex in tri.simplices:
        p0, p1, p2 = pontos_cart[simplex]
        area = 0.5*abs((p1[0]-p0[0])*(p2[1]-p0[1]) - (p2[0]-p0[0])*(p1[1]-p0[1]))
        if abs(area - area_esperada) < 1e-6:
            count += 1
    return count

def testa_proposicao_6_2(limite=5):
    print("\n=== Proposição 6.2: hexágono raio k tem 6k² triângulos elementares ===")
    ok = True
    for k in range(1, limite):
        n_tri = conta_triangulos_delaunay(k)
        esperado = 6*k*k
        bate = n_tri == esperado
        ok &= bate
        print(f"k={k}: triangulos(Delaunay)={n_tri} 6k²={esperado} {'OK' if bate else 'DIVERGIU'}")
    return ok

def testa_maximo_losangos(limite=5):
    print("\n=== Máximo teórico de losangos: floor(6k²/2) = 3k² ===")
    ok = True
    for k in range(1, limite):
        maximo = (6*k*k)//2
        esperado = 3*k*k
        bate = maximo == esperado
        ok &= bate
    print(f"floor(6k²/2)==3k² para k=1..{limite-1}? {ok}")
    return ok

def testa_hexagonos_menores(limite=5):
    print("\n=== Hexágonos menores: número de hexágonos completos = H(k-1) ===")
    # o documento afirma: para k=3, 19 hexagonos = H(2)=19
    for k in range(1, limite):
        h_k_menos_1 = H(k-1) if k >= 1 else 0
        print(f"k={k}: H(k-1)={h_k_menos_1}")
    print("(H(2)=19 esperado para k=3, conforme documento)")
    print(f"H(2) = {H(2)} {'OK, bate com documento' if H(2)==19 else 'DIVERGIU'}")

def testa_cubo_losangos():
    print("\n=== Seção 8.1: hexágono dividido em 3 losangos, ângulos somam 360° ===")
    # hexágono regular, 3 eixos internos a partir do centro dividem em 3 losangos
    # cada losango tem 2 ângulos de 60° e 2 de 120° (é a forma de 2 triangulos equilateros colados)
    angulo_obtuso_losango = 120
    soma = 3 * angulo_obtuso_losango
    print(f"3 x 120° = {soma}° (esperado 360°): {'OK' if soma == 360 else 'DIVERGIU'}")

    # verificacao geometrica direta: os 3 losangos realmente cobrem o hexagono sem sobrar/faltar?
    # hexagono regular de raio 1, dividido pelos 3 eixos que ligam centro aos vertices alternados
    vertices_hex = [(np.cos(i*np.pi/3), np.sin(i*np.pi/3)) for i in range(6)]
    centro = (0,0)
    area_hexagono = 6 * (np.sqrt(3)/4)  # 6 triangulos equilateros de lado 1
    # cada losango = 2 triangulos elementares
    area_losango = 2 * (np.sqrt(3)/4)
    area_3_losangos = 3 * area_losango
    print(f"Área hexágono (6 triângulos elementares): {area_hexagono:.4f}")
    print(f"Área 3 losangos (6 triângulos elementares, agrupados 2 a 2): {area_3_losangos:.4f}")
    print(f"Áreas batem? {abs(area_hexagono - area_3_losangos) < 1e-9}")

def testa_octaedro_hexagono():
    print("\n=== Seção 8.2/8.3: projeção do octaedro no eixo de simetria 3 = hexágono ===")
    # Octaedro regular: vertices em (+-1,0,0),(0,+-1,0),(0,0,+-1)
    vertices = np.array([
        [1,0,0],[-1,0,0],[0,1,0],[0,-1,0],[0,0,1],[0,0,-1]
    ], dtype=float)
    # eixo de simetria de ordem 3: direcao (1,1,1)/sqrt(3)
    eixo = np.array([1,1,1])/np.sqrt(3)

    # projeta os vertices no plano perpendicular ao eixo
    def projeta_no_plano(v, eixo):
        return v - np.dot(v, eixo)*eixo

    projetados = np.array([projeta_no_plano(v, eixo) for v in vertices])

    # cria uma base 2D no plano perpendicular
    # dois vetores ortogonais a eixo
    e1 = np.array([1,-1,0])/np.sqrt(2)
    e2 = np.cross(eixo, e1)
    coords_2d = np.array([[np.dot(p, e1), np.dot(p, e2)] for p in projetados])

    # calcula angulos e distancias ao centro (deveria formar hexagono regular)
    distancias = [np.linalg.norm(c) for c in coords_2d]
    angulos = sorted([np.degrees(np.arctan2(c[1], c[0])) % 360 for c in coords_2d])

    print(f"Distâncias dos 6 vértices projetados ao centro: {[round(d,4) for d in distancias]}")
    print(f"Todas iguais (hexágono regular)? {np.allclose(distancias, distancias[0])}")

    diffs_angulares = [(angulos[(i+1)%6] - angulos[i]) % 360 for i in range(6)]
    print(f"Diferenças angulares entre vértices consecutivos: {[round(d,2) for d in diffs_angulares]}")
    print(f"Todas ~60°? {np.allclose(diffs_angulares, 60, atol=0.01)}")

if __name__ == "__main__":
    r1 = testa_H_k(6)
    try:
        r2 = testa_proposicao_6_2(5)
    except ImportError:
        print("scipy nao disponivel, pulando teste de Delaunay")
        r2 = None
    r3 = testa_maximo_losangos(5)
    testa_hexagonos_menores(4)
    testa_cubo_losangos()
    testa_octaedro_hexagono()
