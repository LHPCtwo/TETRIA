"""
voxeliza_bunny_real.py -- RECONSTRUCAO (o original se perdeu).

Voxeliza a SUPERFICIE de um mesh .obj numa grade L^3 (README v9, entrada [9]).
Interface usada por gera_world_bunny_stream.py e gera_world_sparse_stream.py:
    le_obj_vertices_faces(path) -> (vertices, faces)
    voxeliza_superficie(vertices, faces, L) -> set de (x, y, z)

Convencao (MEDIDA contra assets/world_bunny_32.stream, nao suposta):
  - cubo normalizado: escala unica (L-1) / maior extensao do bbox
  - origem no minimo do bbox, sem inverter eixos, indice = floor(coordenada)
  - cada triangulo amostrado numa grade baricentrica de passo ~1/2 voxel

LIMITE REAL: a amostragem do original nao foi recuperada. Contra o seu
world_bunny_32.stream esta versao acerta ~95% dos voxels (Jaccard ~0,95).
NAO e identica bit a bit. Use os .stream que voce ja tem como referencia;
rode py/confere_voxelizacao.py para ver a diferenca.
"""
import math


def le_obj_vertices_faces(path):
    vertices, faces = [], []
    with open(path) as f:
        for ln in f:
            if ln.startswith("v "):
                vertices.append(tuple(float(t) for t in ln.split()[1:4]))
            elif ln.startswith("f "):
                faces.append(tuple(int(t.split("/")[0]) - 1 for t in ln.split()[1:4]))
    return vertices, faces


def voxeliza_superficie(vertices, faces, L):
    mn = [min(v[i] for v in vertices) for i in range(3)]
    mx = [max(v[i] for v in vertices) for i in range(3)]
    s = (L - 1) / max(mx[i] - mn[i] for i in range(3))
    Q = [tuple((v[i] - mn[i]) * s for i in range(3)) for v in vertices]

    def cel(p):
        return tuple(min(L - 1, max(0, int(math.floor(c)))) for c in p)

    ocupado = set()
    for ia, ib, ic in faces:
        a, b, c = Q[ia], Q[ib], Q[ic]
        maxedge = max(math.dist(a, b), math.dist(b, c), math.dist(c, a))
        n = max(1, math.ceil(2 * maxedge))
        for i in range(n + 1):
            for j in range(n + 1 - i):
                u, v = i / n, j / n
                w = 1 - u - v
                ocupado.add(cel(tuple(a[k] * w + b[k] * u + c[k] * v for k in range(3))))
    return ocupado
