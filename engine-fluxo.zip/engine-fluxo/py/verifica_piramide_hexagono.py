"""Verifica Teorema 4.1 (piramide simetrica = quadrado perfeito),
H(k)=3k^2+3k+1 (hexagonais centrados) e Teorema 5.2 (H(k) via trapezio
espelhado)."""

def soma_piramide_simetrica(p):
    """1,2,...,p-1,p,p-1,...,2,1"""
    linha = list(range(1,p)) + [p] + list(range(p-1,0,-1))
    return sum(linha), linha

def anel_hexagonal_H(k):
    """H(k) = 3k^2+3k+1, contagem acumulada incluindo centro."""
    return 3*k*k + 3*k + 1

def T(n):
    return n*(n+1)//2

def testa_piramide(limite=20):
    print("=== Teorema 4.1: soma da piramide simetrica = p^2 ===")
    ok = True
    for p in range(1, limite):
        soma, linha = soma_piramide_simetrica(p)
        esperado = p*p
        bate = soma == esperado
        ok &= bate
        if not bate:
            print(f"p={p}: soma={soma} p^2={esperado} DIVERGIU")
    print(f"Todos os p=1..{limite-1} batem? {ok}")
    return ok

def testa_hexagonal(limite=20):
    print("\n=== H(k) = 3k^2+3k+1, construcao por aneis (6k pontos por anel) ===")
    ok = True
    for k in range(0, limite):
        # constroi por soma de aneis: H(0)=1 (centro), H(k)=H(k-1)+6k
        acumulado = 1
        for i in range(1, k+1):
            acumulado += 6*i
        formula = anel_hexagonal_H(k)
        bate = acumulado == formula
        ok &= bate
        if not bate:
            print(f"k={k}: acumulado(aneis)={acumulado} formula={formula} DIVERGIU")
    print(f"Todos os k=0..{limite-1} batem? {ok}")
    return ok

def testa_espelhamento(limite=20):
    print("\n=== Teorema 5.2: H(k) = 2(T_2k - T_k) + (2k+1) ===")
    ok = True
    for k in range(0, limite):
        H_k = anel_hexagonal_H(k)
        trapezio = T(2*k) - T(k)
        formula = 2*trapezio + (2*k+1)
        bate = H_k == formula
        ok &= bate
        if not bate:
            print(f"k={k}: H(k)={H_k} formula={formula} DIVERGIU")
    print(f"Todos os k=0..{limite-1} batem? {ok}")
    return ok

def testa_anel_gnomon(limite=20):
    """p^2 - (p-1)^2 = 2p-1"""
    print("\n=== Gnomon: p^2 - (p-1)^2 = 2p-1 ===")
    ok = True
    for p in range(1, limite):
        gnomon = p*p - (p-1)*(p-1)
        esperado = 2*p - 1
        bate = gnomon == esperado
        ok &= bate
    print(f"Todos os p=1..{limite-1} batem? {ok}")
    return ok

if __name__ == "__main__":
    r1 = testa_piramide(30)
    r2 = testa_hexagonal(30)
    r3 = testa_espelhamento(30)
    r4 = testa_anel_gnomon(30)
    print(f"\n=== TODOS OS TEOREMAS DA SEÇÃO 4-5 CONFIRMADOS: {all([r1,r2,r3,r4])} ===")
