import time
from octree3d import build_octree, count_nodes, make_sphere_occ, make_terrain_occ, make_noise_occ

def testa(nome, occ_factory, L):
    occ = occ_factory(L)
    t0 = time.time()
    tree = build_octree(occ, 0, 0, 0, L)
    dt = time.time() - t0
    n = count_nodes(tree)
    raw = L**3
    print(f"{nome:>10} L={L:<4} raw={raw:>9,}  nos={n:>9,}  razao={n/raw:.5f}  tempo={dt:.1f}s")
    return n, raw

print(f"{'tipo':>10} {'L':<6} {'raw':>10} {'nos':>10} {'razao':>10}")
for L in [16, 32, 64]:
    testa("esfera",  make_sphere_occ, L)
    testa("terreno", make_terrain_occ, L)
    testa("ruido",   make_noise_occ, L)
    print()

print("--- L maior, so esfera e terreno (ruido ja comprovado incompressivel) ---")
testa("esfera",  make_sphere_occ, 128)
testa("terreno", make_terrain_occ, 128)
