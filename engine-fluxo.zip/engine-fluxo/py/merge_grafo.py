"""
Fusão de blocos via grafo (union-find), usando truncamento por
DESLOCAMENTO (shift), que é a técnica correta quando o objetivo é
dimensionar/medir magnitude -- diferente do truncamento por MÁSCARA
(AND com repunit), que é uma técnica igualmente válida mas para outro
objetivo: reduzir custo de operação (evitar DIV/MOD em hardware),
sem garantir preservar a ordem de grandeza do valor.

  - shift:   i >> k        == floor(i / 2^k)   -> preserva magnitude
  - máscara: i & (2^k - 1) == i mod 2^k        -> preserva resíduo

Aqui usamos o shift porque o objetivo agora é dimensionar: decidir se
blocos vizinhos podem ser fundidos numa única região representativa.
"""

class UnionFind:
    def __init__(self, n):
        self.parent = list(range(n))
    def find(self, x):
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x
    def union(self, a, b):
        ra, rb = self.find(a), self.find(b)
        if ra != rb:
            self.parent[ra] = rb


def trunca_por_shift(valor, k):
    """floor(valor / 2^k) via deslocamento de bits -- sem divisão."""
    return valor >> k


def make_occ(L, k_bloco, c):
    def occ(x, y):
        if x + y >= L:
            return 0
        if c <= x < c + k_bloco and c <= y < c + k_bloco:
            return 2
        return 1
    return occ


def constroi_grafo_blocos(occ, L, lado_bloco, k_shift):
    """
    Divide a malha L x L em blocos de lado `lado_bloco`, calcula o valor
    truncado (via shift) de cada bloco, e funde blocos ADJACENTES que
    têm o mesmo valor truncado -- um grafo de fusão (union-find), não
    uma árvore de subdivisão espacial fixa como o quadtree.
    """
    nb = (L + lado_bloco - 1) // lado_bloco
    truncado = {}
    for by in range(nb):
        for bx in range(nb):
            y0, x0 = by * lado_bloco, bx * lado_bloco
            v = occ(x0, y0)
            truncado[(bx, by)] = trunca_por_shift(v, k_shift)

    uf = UnionFind(nb * nb)
    idx = lambda bx, by: by * nb + bx

    for by in range(nb):
        for bx in range(nb):
            if bx + 1 < nb and truncado[(bx, by)] == truncado[(bx + 1, by)]:
                uf.union(idx(bx, by), idx(bx + 1, by))
            if by + 1 < nb and truncado[(bx, by)] == truncado[(bx, by + 1)]:
                uf.union(idx(bx, by), idx(bx, by + 1))

    componentes = {}
    for by in range(nb):
        for bx in range(nb):
            r = uf.find(idx(bx, by))
            componentes.setdefault(r, []).append((bx, by))

    return componentes, truncado, nb


def demo_escala():
    print(f"{'L':>6} {'blocos':>8} {'componentes':>12} {'razão':>10}")
    for L in [32, 64, 128, 256, 512, 1024]:
        k_bloco = L // 3
        c = (L - k_bloco) // 2
        occ = make_occ(L, k_bloco, c)
        comps, _, nb = constroi_grafo_blocos(occ, L, lado_bloco=4, k_shift=1)
        total_blocos = nb * nb
        print(f"{L:>6} {total_blocos:>8} {len(comps):>12} {len(comps)/total_blocos:>10.4f}")


if __name__ == "__main__":
    demo_escala()
