"""
Testa a hipótese registrada na Seção 20.2 do relatório: se
SpatialPartition usasse subdivisão em m partes (não necessariamente 2)
escolhido para alinhar com o k/L típico dos dados, a constante de
compressão poderia melhorar.

Generaliza o teste de homogeneidade geométrico exato (Seção 9.1,
homogeneidade_exata.py) de subdivisão binária (quadtree, m=2) para
m-ária (m-tree, m qualquer): cada nó não-homogêneo se divide em m×m
sub-regiões, não 4.

Testa m em {2,3,4,5,6,8} contra os casos já conhecidos da Tabela 3
(k/L = 1/4, 1/3, 1/2), pra ver se algum m bate o quadtree (m=2) no pior
caso (k/L=1/3, que deu nós/L=6,66 vs 4,00 dos casos bem alinhados).
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class MNode:
    x0: int
    y0: int
    size: int
    value: Optional[int] = None
    children: Optional[list] = None


def _overlap_1d(a0, a1, b0, b1):
    return max(a0, b0), min(a1, b1)


def region_value_exact(L, k, c, x0, y0, size):
    """Mesmo teste exato de homogeneidade_exata.py — independe de m,
    só depende da geometria (hipotenusa + bloco)."""
    x1, y1 = x0 + size - 1, y0 + size - 1
    min_sum, max_sum = x0 + y0, x1 + y1

    if min_sum < L <= max_sum:
        return None
    if min_sum >= L:
        return 0
    if k <= 0:
        return 1

    bx0, bx1, by0, by1 = c, c + k - 1, c, c + k - 1
    ox0, ox1 = _overlap_1d(x0, x1, bx0, bx1)
    oy0, oy1 = _overlap_1d(y0, y1, by0, by1)
    if not (ox0 <= ox1 and oy0 <= oy1):
        return 1
    if x0 >= bx0 and x1 <= bx1 and y0 >= by0 and y1 <= by1:
        return 2
    return None


def build_mtree(L, k, c, x0, y0, size, m):
    v = region_value_exact(L, k, c, x0, y0, size)
    if v is not None:
        return MNode(x0, y0, size, value=v)
    if size < m:
        # não dá pra subdividir mais em m partes iguais; trata como folha
        # forçada (equivalente a size=1 do quadtree) -- não deveria
        # acontecer se size for sempre potência de m
        return MNode(x0, y0, size, value=region_value_exact(L, k, c, x0, y0, 1) or 1)

    sub = size // m
    children = []
    for i in range(m):
        for j in range(m):
            children.append(build_mtree(L, k, c, x0 + i*sub, y0 + j*sub, sub, m))
    return MNode(x0, y0, size, children=children)


def count_nodes(node):
    if node.children is None:
        return 1
    return 1 + sum(count_nodes(c) for c in node.children)


def proxima_potencia_de_m(L, m):
    size = 1
    while size < L:
        size *= m
    return size


def testa_m(L, k, m):
    c = (L - k) // 2
    size = proxima_potencia_de_m(L, m)
    tree = build_mtree(L, k, c, 0, 0, size, m)
    n = count_nodes(tree)
    return n, size


def demo_comparacao(L=256):
    fracoes = [("1/4", 1/4), ("1/3", 1/3), ("1/2", 1/2)]
    ms = [2, 3, 4, 5, 6, 8]

    print(f"--- L={L}, comparando m-tree para m in {ms} ---\n")
    resultados = {}
    for label, frac in fracoes:
        k = max(1, int(L * frac))
        print(f"k/L={label} (k={k}):")
        print(f"  {'m':>4} {'size(grade)':>12} {'nos':>10} {'nos/L':>10}")
        melhores = []
        for m in ms:
            n, size = testa_m(L, k, m)
            ratio = n / L
            melhores.append((m, n, ratio))
            print(f"  {m:>4} {size:>12,} {n:>10,} {ratio:>10.3f}")
        melhor = min(melhores, key=lambda t: t[2])
        print(f"  --> melhor m para k/L={label}: m={melhor[0]} (nos/L={melhor[2]:.3f})\n")
        resultados[label] = melhores
    return resultados


def demo_comparacao_sem_vies_de_padding():
    """
    Versão corrigida: em vez de fixar L=256 pra todo m (o que força
    grades muito maiores que L para m != potência de 2, inflando nós
    por preenchimento, não pela hipótese em si), escolhe L EXATO como
    potência de cada m -- sem sobra, comparação justa.
    """
    print("--- Comparação sem viés de padding: L = m^depth exato para cada m ---\n")
    for label, frac_num, frac_den in [("1/4", 1, 4), ("1/3", 1, 3), ("1/2", 1, 2)]:
        print(f"k/L={label}:")
        print(f"  {'m':>4} {'depth':>6} {'L(exato)':>10} {'nos':>10} {'nos/L':>10}")
        for m in [2, 3, 4, 5, 6, 8]:
            # acha depth tal que L=m^depth fique perto de 256 (mesma ordem
            # de grandeza pra todos, sem sobra de preenchimento)
            depth = 1
            while m ** depth < 200:
                depth += 1
            L = m ** depth
            k = max(1, (L * frac_num) // frac_den)
            c = (L - k) // 2
            tree = build_mtree(L, k, c, 0, 0, L, m)  # size=L exato, sem padding
            n = count_nodes(tree)
            print(f"  {m:>4} {depth:>6} {L:>10,} {n:>10,} {n/L:>10.3f}")
        print()


def demo_teste_alinhamento_por_base():
    """
    Testa a hipótese refinada: m alinha bem com k/L quando k/L é uma
    fração "simples" na base m (ex.: 1/3 e 1/9 são simples em base 3,
    do mesmo jeito que 1/4 e 1/2 são simples em base 2). Testa cada
    fração contra SEU m "natural" e contra m=2 (baseline), pra ver se o
    padrão se generaliza além do caso único k/L=1/3, m=3 já visto.
    """
    print("--- Teste de alinhamento por base: fração natural de cada m vs m=2 ---\n")
    casos = [
        ("1/3 (natural de m=3)", 1, 3, 3),
        ("1/9 (natural de m=3)", 1, 9, 3),
        ("1/5 (natural de m=5)", 1, 5, 5),
        ("1/6 (natural de m=6)", 1, 6, 6),
        ("1/7 (natural de m=7)", 1, 7, 7),
        ("1/8 (natural de m=2, ja bom)", 1, 8, 2),
    ]
    print(f"{'fracao':>28} {'nos/L (m=2)':>14} {'nos/L (m natural)':>18} {'m natural vence?':>18}")
    for label, num, den, m_natural in casos:
        # m=2 baseline
        depth2 = 1
        while 2 ** depth2 < 200: depth2 += 1
        L2 = 2 ** depth2
        k2 = max(1, (L2*num)//den)
        c2 = (L2-k2)//2
        n2 = count_nodes(build_mtree(L2, k2, c2, 0, 0, L2, 2))
        ratio2 = n2/L2

        # m natural
        depthm = 1
        while m_natural ** depthm < 200: depthm += 1
        Lm = m_natural ** depthm
        km = max(1, (Lm*num)//den)
        cm = (Lm-km)//2
        nm = count_nodes(build_mtree(Lm, km, cm, 0, 0, Lm, m_natural))
        ratiom = nm/Lm

        vence = "SIM" if ratiom < ratio2 else "nao"
        print(f"{label:>28} {ratio2:>14.3f} {ratiom:>18.3f} {vence:>18}")


if __name__ == "__main__":
    demo_comparacao()
    print("\n" + "="*70 + "\n")
    demo_comparacao_sem_vies_de_padding()
    print("\n" + "="*70 + "\n")
    demo_teste_alinhamento_por_base()
