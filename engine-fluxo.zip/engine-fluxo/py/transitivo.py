def f(L, k):
    return L*L - k*(k+1)

L = 100
print(f"L={L} fixo, variando k -- diferença f(L,k) - f(L,k+1)")
print(f"{'k':>4} {'f(L,k)':>8} {'delta (perde ao k+1)':>22} {'2(k+1) previsto':>18}")
for k in range(0, 15):
    delta = f(L,k) - f(L,k+1)
    previsto = 2*(k+1)
    print(f"{k:>4} {f(L,k):>8} {delta:>22} {previsto:>18} {'sim' if delta==previsto else 'NAO'}")

# telescoping: soma dos deltas de k=0 até k=m-1 deveria reconstruir f(L,0)-f(L,m)
print("\n--- checagem telescópica ---")
m = 10
soma_deltas = sum(2*(k+1) for k in range(m))
direto = f(L,0) - f(L,m)
print(f"soma dos deltas (k=0..{m-1}): {soma_deltas}")
print(f"f(L,0) - f(L,{m}) direto: {direto}")
print("bate?", soma_deltas == direto)

# relacao com numeros gnomon classicos: soma dos gnomons impares da = quadrado perfeito
print("\n--- conexao com gnomons classicos (numeros triangulares/quadrados) ---")
print("gnomon classico: soma de (2i-1) para i=1..n = n^2")
print("aqui: gnomon generalizado 2(k+1), soma de k=0..m-1 = m(m+1) = 2*T(m)")
print("m(m+1) para m=10:", 10*11)
