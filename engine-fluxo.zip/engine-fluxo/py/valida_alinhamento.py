from compress_demo import make_occ, build_quadtree, count_nodes
from fractions import Fraction

L = 4096
print(f"--- L={L} fixo, variando k/L ---")
for frac in [Fraction(1,4), Fraction(1,6), Fraction(1,3), Fraction(3,8), Fraction(1,2), Fraction(5,8)]:
    k = int(L*frac)
    c = (L-k)//2
    occ = make_occ(L, k, c)
    tree = build_quadtree(occ, 0, 0, L)
    n = count_nodes(tree)
    print(f"k/L={str(frac):>5}  k={k:>5}  nos={n:>8,}  nos/L={n/L:.4f}")
