"""
Demonstração de compressão por homogeneidade (estilo quadtree/octree)
aplicada à malha triangular L x L com bloco central k x k.

Ideia central:
  - value(x, y) = 2  se (x,y) está dentro do bloco central k x k
  - value(x, y) = 1  se (x,y) está dentro do triângulo (x + y < L) mas fora do bloco
  - value(x, y) = 0  se (x,y) está fora do triângulo

Um quadtree só subdivide uma região quando ela NÃO é homogênea. Como as
únicas fronteiras são retas (os 4 lados do quadrado e a hipotenusa do
triângulo), o número de folhas cresce ~ O(L) (proporcional ao perímetro
das fronteiras), não O(L^2) (proporcional à área). Isso é testado e
medido abaixo para valores grandes de L.

A segunda parte estende a ideia para 3D processando o volume fatia por
fatia (streaming): cada fatia z é comprimida com um quadtree 2D e depois
descartada, então a memória de pico é O(tamanho de uma fatia comprimida),
não O(L^3).
"""

from dataclasses import dataclass
from typing import Optional, Callable


# ---------------------------------------------------------------------
# 1. QUADTREE 2D COM TESTE DE HOMOGENEIDADE
# ---------------------------------------------------------------------

@dataclass
class QuadNode:
    x0: int
    y0: int
    size: int
    value: Optional[int] = None            # != None  => folha homogênea
    children: Optional[list] = None         # 4 QuadNode, se subdividido


def region_value(occ: Callable[[int, int], int], x0: int, y0: int, size: int):
    """
    Retorna o valor único da região [x0,x0+size) x [y0,y0+size) se ela for
    homogênea, ou None caso contrário.

    Em vez de varrer célula a célula (o que anularia o ganho), usamos uma
    verificação O(1) baseada na geometria conhecida do problema: uma
    região é homogênea sse os quatro cantos + o centro concordam E a
    região não é cruzada por nenhuma das retas de fronteira (lados do
    quadrado e hipotenusa). Isso é o análogo de um "teste de fronteira"
    que um motor gráfico real faria com bounding boxes/planos.
    """
    corners = [
        occ(x0, y0), occ(x0 + size - 1, y0),
        occ(x0, y0 + size - 1), occ(x0 + size - 1, y0 + size - 1),
        occ(x0 + size // 2, y0 + size // 2),
    ]
    if len(set(corners)) != 1:
        return None
    # mesmo com cantos iguais, uma região pode ser cruzada por uma reta
    # fina (ex.: hipotenusa) sem que os cantos amostrados percebam --
    # para blocos pequenos (size<=2) fazemos a checagem exata.
    if size <= 2:
        vals = [occ(x, y) for x in range(x0, x0 + size) for y in range(y0, y0 + size)]
        if len(set(vals)) != 1:
            return None
        return vals[0]
    return corners[0]


def build_quadtree(occ: Callable[[int, int], int], x0: int, y0: int, size: int) -> QuadNode:
    v = region_value(occ, x0, y0, size)
    if v is not None:
        return QuadNode(x0, y0, size, value=v)
    half = size // 2
    children = [
        build_quadtree(occ, x0,        y0,        half),
        build_quadtree(occ, x0 + half, y0,        half),
        build_quadtree(occ, x0,        y0 + half, half),
        build_quadtree(occ, x0 + half, y0 + half, half),
    ]
    return QuadNode(x0, y0, size, children=children)


def count_nodes(node: QuadNode) -> int:
    if node.children is None:
        return 1
    return 1 + sum(count_nodes(c) for c in node.children)


def query(node: QuadNode, x: int, y: int) -> int:
    """Reconstrói o valor de um ponto sob demanda, sem materializar a malha inteira."""
    if node.children is None:
        return node.value
    half = node.size // 2
    idx = (1 if x >= node.x0 + half else 0) + (2 if y >= node.y0 + half else 0)
    return query(node.children[idx], x, y)


def make_occ(L: int, k: int, c: int):
    def occ(x: int, y: int) -> int:
        if x + y >= L:          # fora do triângulo
            return 0
        if c <= x < c + k and c <= y < c + k:   # dentro do bloco central
            return 2
        return 1                # malha (T1/T2) fora do bloco
    return occ


def demo_2d(L: int, k: int):
    c = (L - k) // 2
    # L deve ser potência de 2 para o quadtree simples abaixo; ajusta pra cima.
    size = 1
    while size < L:
        size *= 2
    occ = make_occ(L, k, c)
    tree = build_quadtree(occ, 0, 0, size)

    raw_cells = size * size
    nodes = count_nodes(tree)
    leaves = sum(1 for n in _walk(tree) if n.children is None)

    print(f"--- 2D: L={L}, k={k}, grade útil {size}x{size} ---")
    print(f"células brutas (size^2):      {raw_cells:>12,}")
    print(f"nós do quadtree (total):       {nodes:>12,}")
    print(f"folhas do quadtree:            {leaves:>12,}")
    print(f"razão de compressão (nós/raw): {nodes/raw_cells:.6f}")

    # sanity check: reconstrução ponto a ponto bate com occ() original
    import random
    random.seed(0)
    for _ in range(2000):
        x = random.randrange(0, min(L, size))
        y = random.randrange(0, min(L, size))
        assert query(tree, x, y) == occ(x, y), (x, y)
    print("checagem de reconstrução: OK (2000 pontos aleatórios)")
    print()
    return tree, size


def _walk(node: QuadNode):
    yield node
    if node.children:
        for c in node.children:
            yield from _walk(c)


# ---------------------------------------------------------------------
# 2. STREAMING 3D: PROCESSA O VOLUME FATIA POR FATIA
# ---------------------------------------------------------------------

def demo_3d_streaming(L: int, k: int):
    """
    Volume conceitual: para z < k, a fatia é igual à malha 2D com bloco
    central (como se o bloco fosse extrudado até altura k). Para z >= k,
    a fatia é só a malha triangular (T1+T2), sem bloco.

    Em vez de alocar um array L x L x L, comprimimos e descartamos uma
    fatia por vez -- a "memória de pico" é o tamanho do maior quadtree
    de uma única fatia, não o volume inteiro.
    """
    c = (L - k) // 2
    size = 1
    while size < L:
        size *= 2

    peak_nodes_single_slice = 0
    total_nodes_if_stored_all = 0   # soma de todas as fatias (comparação)
    raw_total = size * size * L      # L fatias de size*size células

    for z in range(L):
        if z < k:
            occ = make_occ(L, k, c)          # fatia "dentro" do bloco extrudado
        else:
            occ = make_occ(L, 0, c)          # sem bloco, só a malha (k=0)
        tree = build_quadtree(occ, 0, 0, size)
        n = count_nodes(tree)
        peak_nodes_single_slice = max(peak_nodes_single_slice, n)
        total_nodes_if_stored_all += n
        # a fatia é descartada aqui (streaming) -- só usamos `n` e seguimos

    print(f"--- 3D streaming: L={L}, k={k}, {L} fatias de {size}x{size} ---")
    print(f"células brutas do volume (L*size^2):   {raw_total:>14,}")
    print(f"nós somados de TODAS as fatias:         {total_nodes_if_stored_all:>14,}")
    print(f"pico de nós de UMA fatia (streaming):   {peak_nodes_single_slice:>14,}")
    print(f"razão pico-streaming / bruto:           {peak_nodes_single_slice/raw_total:.8f}")
    print()


if __name__ == "__main__":
    for L, k in [(16, 5), (256, 70), (2048, 600)]:
        demo_2d(L, k)

    demo_3d_streaming(256, 70)
