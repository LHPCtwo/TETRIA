from compress_demo import make_occ, build_quadtree, count_nodes
import math

print(f"{'L':>8} {'k':>6} {'size^2':>12} {'nos':>10} {'nos/L (esperado O(L))':>24}")
for L in [16,32,64,128,256,512,1024,2048,4096]:
    k = L//3
    c = (L-k)//2
    size=1
    while size<L: size*=2
    occ = make_occ(L,k,c)
    tree = build_quadtree(occ,0,0,size)
    n = count_nodes(tree)
    print(f"{L:>8} {k:>6} {size*size:>12,} {n:>10,} {n/L:>24.2f}")
