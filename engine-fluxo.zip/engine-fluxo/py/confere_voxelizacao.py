"""Compara py/voxeliza_bunny_real.py com um .stream WFLB seu.
Uso: python3 -I py/confere_voxelizacao.py assets/stanford-bunny.obj assets/world_bunny_32.stream"""
import os, struct, sys, importlib.util
here = os.path.dirname(os.path.abspath(__file__))
spec = importlib.util.spec_from_file_location("vb", os.path.join(here, "voxeliza_bunny_real.py"))
vb = importlib.util.module_from_spec(spec); spec.loader.exec_module(vb)
obj, ref = sys.argv[1], sys.argv[2]
d = open(ref, "rb").read(); L, n = struct.unpack("<ii", d[4:12]); bs = (L * L + 7) // 8
gt = {(i % L, i // L, z) for z in range(n) for i in range(L * L)
      if d[12 + z * bs + i // 8] >> (i % 8) & 1}
V, F = vb.le_obj_vertices_faces(obj)
o = vb.voxeliza_superficie(V, F, L)
print(f"L={L} referencia={len(gt)} reconstrucao={len(o)} em comum={len(o & gt)} "
      f"faltam={len(gt - o)} sobram={len(o - gt)} jaccard={len(o & gt) / len(o | gt):.4f}")
