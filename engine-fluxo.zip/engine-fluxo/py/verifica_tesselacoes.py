"""
Verificação: quais formas conseguimos tesselar (ladrilhar o plano sem
lacunas nem sobreposições), na mesma linha "artesanal" do Passo 5/6 do
registro -- peça repetida lado a lado, sem projeção nem coordenadas
homogêneas.

Critério matemático (vértice-a-vértice, tesselação regular/semi-regular):
num vértice onde N polígonos se encontram, a soma dos ângulos internos
deve fechar exatamente 360°. Para um único tipo de polígono regular de
n lados, o ângulo interno é:

    ang(n) = (n-2) * 180 / n

e ele tesselava sozinho SSE 360 / ang(n) for um inteiro >= 3.
"""

from fractions import Fraction


def angulo_interno(n: int) -> Fraction:
    """Ângulo interno de um polígono regular de n lados, em graus (exato)."""
    return Fraction(n - 2, n) * 180


def tesselam_sozinhos(max_lados: int = 12):
    """Testa polígonos regulares de 3 a max_lados lados: qual tesselam sozinhos?"""
    resultados = []
    for n in range(3, max_lados + 1):
        ang = angulo_interno(n)
        num_por_vertice = Fraction(360) / ang
        tesselam = num_por_vertice.denominator == 1 and num_por_vertice >= 3
        resultados.append((n, float(ang), num_por_vertice, tesselam))
    return resultados


def demo_poligonos_regulares():
    print("=== Quais polígonos regulares tesselam o plano sozinhos? ===")
    print(f"{'lados':>6} {'nome':>12} {'ang.interno':>12} {'por vertice':>14} {'tesselam?':>10}")
    nomes = {3: "triângulo", 4: "quadrado", 5: "pentágono", 6: "hexágono",
             7: "heptágono", 8: "octógono", 9: "eneágono", 10: "decágono",
             11: "undecágono", 12: "dodecágono"}
    vencedores = []
    for n, ang, num, ok in tesselam_sozinhos():
        nome = nomes.get(n, f"{n}-gono")
        status = "SIM" if ok else "não"
        extra = f"({num} por vértice)" if ok else ""
        print(f"{n:>6} {nome:>12} {ang:>12.2f} {str(num):>14} {status:>10} {extra}")
        if ok:
            vencedores.append(n)
    print(f"\nResultado: apenas n em {vencedores} tesselam sozinhos "
          f"(triângulo equilátero, quadrado, hexágono regular).")
    print("Isso é um fato clássico (os 3 'tilings regulares'), não uma suposição -- "
          "verificado aqui por divisibilidade exata de 360° pelo ângulo interno.")
    return vencedores


# ---------------------------------------------------------------------
# Tesselações SEMI-regulares (mais de um tipo de polígono, mas todo
# vértice com a mesma configuração) -- as 8 conhecidas classicamente.
# Verificamos aqui que a soma de ângulos fecha 360 para cada uma.
# ---------------------------------------------------------------------

CONFIGURACOES_SEMI_REGULARES = {
    "3.3.3.3.3.3 (triangular)":        [3]*6,
    "4.4.4.4 (quadrada)":              [4]*4,
    "6.6.6 (hexagonal)":               [6]*3,
    "3.3.3.3.6":                       [3,3,3,3,6],
    "3.3.3.4.4":                       [3,3,3,4,4],
    "3.3.4.3.4":                       [3,3,4,3,4],
    "3.4.6.4":                         [3,4,6,4],
    "3.6.3.6 (losango/kagome)":        [3,6,3,6],
    "3.12.12":                         [3,12,12],
    "4.6.12":                          [4,6,12],
    "4.8.8":                           [4,8,8],
}


def demo_semi_regulares():
    print("\n=== Verificando configurações semi-regulares conhecidas ===")
    print(f"{'configuracao':>28} {'soma dos angulos':>18} {'fecha 360?':>12}")
    for nome, lados in CONFIGURACOES_SEMI_REGULARES.items():
        soma = sum(angulo_interno(n) for n in lados)
        ok = soma == 360
        print(f"{nome:>28} {float(soma):>18.3f} {'SIM' if ok else 'NAO':>12}")


# ---------------------------------------------------------------------
# O caso do registro: losango = 2 triângulos equiláteros colados.
# Verificamos que o vértice largo (120°) e o estreito (60°) do losango
# se encaixam corretamente na tesselação 3.6.3.6 / triangular.
# ---------------------------------------------------------------------

def demo_losango_do_registro():
    print("\n=== Losango do registro (2 triângulos equiláteros colados) ===")
    ang_tri = angulo_interno(3)
    print(f"Ângulo interno do triângulo equilátero: {float(ang_tri)}°")
    vertice_estreito = ang_tri            # 60°: um único triângulo
    vertice_largo = 2 * ang_tri            # 120°: dois triângulos colados
    print(f"Losango resultante: ângulos {float(vertice_estreito)}° e {float(vertice_largo)}°")
    print(f"Soma dos ângulos internos do losango: "
          f"{float(2*vertice_estreito + 2*vertice_largo)}° (deve ser 360°, soma de "
          f"quadrilátero convexo)")

    # No vértice largo (120°), quantos losangos se encontram para fechar 360?
    n_no_vertice_largo = Fraction(360) / vertice_largo
    n_no_vertice_estreito = Fraction(360) / vertice_estreito
    print(f"No vértice largo (120°): {n_no_vertice_largo} losangos fecham 360° "
          f"({'exato' if n_no_vertice_largo.denominator==1 else 'NAO exato'})")
    print(f"No vértice estreito (60°): {n_no_vertice_estreito} losangos fecham 360° "
          f"({'exato' if n_no_vertice_estreito.denominator==1 else 'NAO exato'})")
    print("Confirma a Figura 3 do registro: a tesselação por losangos 60/120 é válida "
          "porque em cada tipo de vértice um número inteiro de peças fecha 360° exato.")


# ---------------------------------------------------------------------
# Verificação REAL (não heurística) de peças compostas: rasteriza a
# tesselação numa grade fina e confirma cobertura total sem lacunas nem
# sobreposição, por conservação de área (área coberta == área da região,
# dentro da tolerância de discretização).
# ---------------------------------------------------------------------

def _ponto_dentro_triangulo(px, py, ax, ay, bx, by, cx, cy):
    """Teste de sinal (mesmo lado), com folga (eps) na borda para não
    perder pontos exatamente sobre uma aresta compartilhada."""
    eps = 1e-9
    def sinal(x1, y1, x2, y2, x3, y3):
        return (x1 - x3) * (y2 - y3) - (x2 - x3) * (y1 - y3)
    d1 = sinal(px, py, ax, ay, bx, by)
    d2 = sinal(px, py, bx, by, cx, cy)
    d3 = sinal(px, py, cx, cy, ax, ay)
    neg = (d1 < -eps) or (d2 < -eps) or (d3 < -eps)
    pos = (d1 > eps) or (d2 > eps) or (d3 > eps)
    return not (neg and pos)


def gera_triangulos_malha(largura, altura, lado=1.0):
    """
    Gera EXPLICITAMENTE a lista de triângulos da malha, via a transformação
    de cisalhamento x = lado*(i + j/2), y = h*j (h = lado*sqrt(3)/2).
    Cada célula quadrada unitária (i,j) -> (i+1,j+1) vira um paralelogramo,
    dividido em 2 triângulos pela diagonal. Retorna a lista de triângulos
    (cada um como 3 vértices) -- é essa lista, gerada independentemente,
    que usamos para TESTAR a cobertura (não a mesma fórmula usada pra
    classificar pontos, senão o teste seria circular).
    """
    import math
    h = lado * math.sqrt(3) / 2
    max_j = int(altura / h) + 2
    max_i = int(largura / lado) + 2
    # a extensão em i precisa compensar o cisalhamento (i + j/2): em j alto,
    # é preciso i mais negativo para ainda cobrir x=0.
    i_min = -(max_j // 2) - 2

    def para_xy(i, j):
        return lado * (i + j / 2.0), h * j

    triangulos = []
    for j in range(-1, max_j):
        for i in range(i_min, max_i):
            p00 = para_xy(i, j)
            p10 = para_xy(i + 1, j)
            p01 = para_xy(i, j + 1)
            p11 = para_xy(i + 1, j + 1)
            # diagonal do paralelogramo: p10-p01 (padrão), split em 2 triângulos
            triangulos.append((p00, p10, p01))
            triangulos.append((p10, p11, p01))
    return triangulos


def verifica_cobertura_triangular(largura=6.0, altura=4.0, resolucao=150):
    """
    Amostra pontos na região [0,largura)x[0,altura) e conta, PARA CADA
    PONTO, em quantos triângulos da lista (gerada independentemente por
    gera_triangulos_malha) ele cai. Tesselação válida <=> quase todo
    ponto cai em exatamente 1 triângulo (pontos exatamente sobre arestas
    compartilhadas podem contar 2, por isso a tolerância de borda).
    """
    triangulos = gera_triangulos_malha(largura, altura)

    xs = [largura * i / resolucao for i in range(resolucao)]
    ys = [altura * i / resolucao for i in range(resolucao)]

    contagem = {0: 0, 1: 0, 2: 0, 3: 0}
    total = 0
    for x in xs:
        for y in ys:
            total += 1
            hits = 0
            for (a, b, c) in triangulos:
                if _ponto_dentro_triangulo(x, y, a[0], a[1], b[0], b[1], c[0], c[1]):
                    hits += 1
            contagem[min(hits, 3)] += 1

    return total, contagem


def demo_verificacao_real():
    print("\n=== Verificação REAL por rasterização (não heurística) ===")
    print("Malha triangular equilátera de base (da qual losango, trapézio de 3")
    print("triângulos e hexágono de 6 triângulos são todos super-tiles):")
    total, contagem = verifica_cobertura_triangular()
    p0 = contagem[0] / total * 100
    p1 = contagem[1] / total * 100
    p2mais = (contagem[2] + contagem[3]) / total * 100
    print(f"  pontos cobertos por 0 triângulos (lacuna):        {p0:6.3f}%")
    print(f"  pontos cobertos por exatamente 1 triângulo:       {p1:6.3f}%")
    print(f"  pontos cobertos por 2+ triângulos (sobreposição): {p2mais:6.3f}%")
    if p0 < 0.01 and p2mais < 1.0:
        print("  CONFIRMADO: cobertura efetivamente total e sem sobreposição real")
        print("  (o pequeno % de 2+ é esperado: pontos de amostragem caindo bem em")
        print("  cima de arestas compartilhadas, contados nos dois triângulos vizinhos).")
    else:
        print(f"  ATENCAO: {p0:.2f}% de lacuna real detectada -- NAO confirmar tesselação.")
    print()
    print("Conclusão honesta: losango (2 triângulos), trapézio (3 triângulos) e")
    print("hexágono (6 triângulos) tesselam porque são recortes exatos e completos")
    print("da MESMA malha triangular já confirmada acima -- toda peça composta feita")
    print("por união de triângulos adjacentes da mesma malha herda a cobertura total")
    print("dela, sem lacuna nem sobreposição, por construção (partição de uma partição).")
    print()
    print("Isso é diferente de garantir que QUALQUER polígono composto por peças de")
    print("uma malha que tesselava vai tesselar sozinho quando REPETIDO como peça")
    print("única -- isso depende de como as cópias se encaixam entre si, não só da")
    print("malha de origem. Não testado aqui para peças arbitrárias (ex.: 2 quadrados")
    print("colados em formato de 'L' já NÃO tesselaria sozinho da mesma forma simples).")


if __name__ == "__main__":
    demo_poligonos_regulares()
    demo_semi_regulares()
    demo_losango_do_registro()
    demo_verificacao_real()
