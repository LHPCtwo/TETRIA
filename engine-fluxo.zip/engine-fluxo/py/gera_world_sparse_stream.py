"""
Formato WFLS (esparso de verdade): ao contrário do WFLB (bitmap denso
L*L por fatia), guarda só a LISTA de coordenadas ocupadas -- nunca
materializa a grade densa em nenhum ponto do pipeline (geração, disco,
leitura).

Isso resolve o desperdício medido no WFLB: a pirâmide booleana tocava
14x mais células do que existe de dado real (43.680 células tocadas
contra 3.112 voxels ocupados, L=32). Aqui o trabalho é proporcional ao
dado real, não à grade.

Formato (little-endian):
  header:  MAGIC "WFLS" | L (int32) | num_slices (int32)
  índice:  num_slices × offset (int64) -- permite seek O(1) até a fatia
           z mesmo com contagem de pontos variável por fatia
  por fatia: count (int32) | count × (x:uint16, y:uint16), ORDENADOS
             por (x,y) -- ordenação permite particionamento eficiente
             por quadrante na reconstrução (sem precisar rescanear do
             zero a cada nível).
"""
import struct
import sys
import os
import importlib.util

MAGIC = b"WFLS"


def gera_world_sparse_stream(path: str, obj_path: str, L: int):
    _here = os.path.dirname(os.path.abspath(__file__))
    spec = importlib.util.spec_from_file_location("vb", os.path.join(_here, "voxeliza_bunny_real.py"))
    vb = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(vb)

    vertices, faces = vb.le_obj_vertices_faces(obj_path)
    ocupado = vb.voxeliza_superficie(vertices, faces, L)
    print(f"Voxelizado: {len(ocupado):,} voxels ocupados de {L**3:,} "
          f"({len(ocupado)/L**3*100:.2f}%) -- nunca materializado como grade densa daqui em diante")

    # agrupa por z, ordena por (x,y) dentro de cada fatia
    por_fatia = [[] for _ in range(L)]
    for (x, y, z) in ocupado:
        por_fatia[z].append((x, y))
    for z in range(L):
        por_fatia[z].sort()

    with open(path, "wb") as f:
        f.write(MAGIC)
        f.write(struct.pack("<i", L))
        f.write(struct.pack("<i", L))  # num_slices = L

        # reserva espaço pro índice, preenche depois
        index_pos = f.tell()
        f.write(b"\x00" * (8 * L))

        offsets = []
        for z in range(L):
            offsets.append(f.tell())
            pontos = por_fatia[z]
            f.write(struct.pack("<i", len(pontos)))
            for (x, y) in pontos:
                f.write(struct.pack("<HH", x, y))

        f.seek(index_pos)
        for off in offsets:
            f.write(struct.pack("<q", off))

    total_bytes = os.path.getsize(path)
    print(f"Gravado {path}: {total_bytes:,} bytes "
          f"(WFLB denso equivalente seria {4+8+L*((L*L+7)//8):,} bytes)")
    return total_bytes


def le_world_sparse_stream(path: str):
    with open(path, "rb") as f:
        magic = f.read(4)
        assert magic == MAGIC
        L, num_slices = struct.unpack("<ii", f.read(8))
        offsets = struct.unpack(f"<{num_slices}q", f.read(8 * num_slices))
        fatias = []
        for z in range(num_slices):
            f.seek(offsets[z])
            count = struct.unpack("<i", f.read(4))[0]
            pontos = [struct.unpack("<HH", f.read(4)) for _ in range(count)]
            fatias.append(pontos)
    return L, num_slices, fatias


if __name__ == "__main__":
    L = int(sys.argv[1]) if len(sys.argv) > 1 else 32
    out_path = sys.argv[2] if len(sys.argv) > 2 else f"world_bunny_sparse_{L}.stream"
    obj_path = "/home/claude/stanford-bunny.obj"

    tam = gera_world_sparse_stream(out_path, obj_path, L)

    print("\n--- Verificação de reconstrução ---")
    L2, n2, fatias = le_world_sparse_stream(out_path)
    assert L2 == L and n2 == L
    total = sum(len(f) for f in fatias)
    print(f"total de pontos relidos: {total:,}")

    # confirma que bate contra a voxelização direta
    _here = os.path.dirname(os.path.abspath(__file__))
    spec = importlib.util.spec_from_file_location("vb", os.path.join(_here, "voxeliza_bunny_real.py"))
    vb = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(vb)
    vertices, faces = vb.le_obj_vertices_faces(obj_path)
    ocupado_direto = vb.voxeliza_superficie(vertices, faces, L)
    print(f"total direto da voxelizacao: {len(ocupado_direto):,}")
    print(f"bate? {'SIM' if total == len(ocupado_direto) else 'NAO'}")
