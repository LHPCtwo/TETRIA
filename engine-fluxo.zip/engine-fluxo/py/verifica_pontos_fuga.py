"""
Verifica as afirmações conceituais da Seção 7 (pontos de fuga) com uma
câmera sintética PRÓPRIA (não reproduz os números exatos do documento,
que dependem da orientação específica da câmera deles -- testa se os
FENÔMENOS descritos se sustentam de forma independente):

1. Duas retas genuinamente paralelas no espaço 3D convergem EXATAMENTE
   no mesmo ponto de fuga (erro 0°).
2. Um desvio angular introduzido faz os pontos de fuga divergirem.
3. Pitágoras ingênuo em coordenadas de imagem falha mesmo para um
   ângulo 3D real de 90° -- precisa normalizar pela matriz de
   calibração pra recuperar o ângulo certo.
"""
import numpy as np

def camera_pinhole(f, cx, cy):
    return np.array([[f,0,cx],[0,f,cy],[0,0,1]], dtype=float)

def projeta(K, ponto_3d):
    p = K @ ponto_3d
    return p[:2] / p[2]

def rotacao_arbitraria(rx, ry, rz):
    """Rotação 3D arbitrária (Euler XYZ) -- orientação de câmera qualquer."""
    Rx = np.array([[1,0,0],[0,np.cos(rx),-np.sin(rx)],[0,np.sin(rx),np.cos(rx)]])
    Ry = np.array([[np.cos(ry),0,np.sin(ry)],[0,1,0],[-np.sin(ry),0,np.cos(ry)]])
    Rz = np.array([[np.cos(rz),-np.sin(rz),0],[np.sin(rz),np.cos(rz),0],[0,0,1]])
    return Rz @ Ry @ Rx

def ponto_de_fuga(K, R, direcao_mundo):
    """Ponto de fuga de uma direção no espaço, dada a orientação R da câmera."""
    direcao_camera = R.T @ direcao_mundo  # direção no referencial da câmera
    return projeta(K, direcao_camera)

def angulo_entre_raios_calibrados(K, v1_img, v2_img):
    """Converte pontos de fuga na imagem de volta a raios 3D (via K^-1) e
    mede o ângulo real entre eles."""
    Kinv = np.linalg.inv(K)
    r1 = Kinv @ np.array([v1_img[0], v1_img[1], 1.0])
    r2 = Kinv @ np.array([v2_img[0], v2_img[1], 1.0])
    r1 /= np.linalg.norm(r1)
    r2 /= np.linalg.norm(r2)
    cos_ang = np.clip(np.dot(r1, r2), -1, 1)
    return np.degrees(np.arccos(cos_ang))

def angulo_ingenuo_na_imagem(C_img, v1_img, v2_img):
    """Ângulo medido NAIVAMENTE nas coordenadas de imagem (tratando a
    imagem como plano euclidiano comum), sem normalizar pela calibração."""
    d1 = np.array(v1_img) - np.array(C_img)
    d2 = np.array(v2_img) - np.array(C_img)
    cos_ang = np.dot(d1,d2) / (np.linalg.norm(d1)*np.linalg.norm(d2))
    return np.degrees(np.arccos(np.clip(cos_ang,-1,1)))

if __name__ == "__main__":
    K = camera_pinhole(f=500.0, cx=0.0, cy=0.0)
    R = rotacao_arbitraria(0.3, 0.5, 0.2)  # orientação arbitrária de câmera

    print("=== Teste 1: duas direções genuinamente perpendiculares (90° real) ===")
    dir_x = np.array([1,0,0])
    dir_y = np.array([0,1,0])
    Vx = ponto_de_fuga(K, R, dir_x)
    Vy = ponto_de_fuga(K, R, dir_y)
    ang_recuperado = angulo_entre_raios_calibrados(K, Vx, Vy)
    print(f"Ângulo 3D real: 90.0°")
    print(f"Ângulo recuperado via raios calibrados (K^-1): {ang_recuperado:.4f}°")
    print(f"Erro: {abs(ang_recuperado-90):.4f}° {'(bate: erro ~0°, confirma afirmação)' if abs(ang_recuperado-90)<0.01 else 'DIVERGIU'}")

    print("\n=== Teste 2: introduzindo desvio de 8° entre as direções ===")
    ang_desvio = np.radians(8)
    dir_y_desviada = np.array([np.sin(ang_desvio), np.cos(ang_desvio), 0])
    Vy_desviado = ponto_de_fuga(K, R, dir_y_desviada)
    # divergencia entre Vy original e Vy desviado (em graus, via raios calibrados)
    divergencia = angulo_entre_raios_calibrados(K, Vy, Vy_desviado)
    print(f"Desvio introduzido: 8°")
    print(f"Divergência medida entre os pontos de fuga (Vy original vs desviado): {divergencia:.4f}°")
    print("(o documento reporta 13,03° pra uma configuração diferente -- aqui só "
          "confirmamos que HÁ divergência mensurável, não o valor exato deles)")

    print("\n=== Teste 3: Pitágoras ingênuo falha em coordenadas de imagem? ===")
    C_img = (K @ np.array([0,0,1]))[:2]  # projeção do centro óptico (deveria ser cx,cy)
    C_img = np.array([0.0, 0.0])  # centro óptico na imagem = (cx,cy) = (0,0) aqui
    dCVx = np.linalg.norm(Vx - C_img)
    dCVy = np.linalg.norm(Vy - C_img)
    dVxVy = np.linalg.norm(Vx - Vy)
    soma_quadrados = dCVx**2 + dCVy**2
    hipotenusa_quad = dVxVy**2
    discrepancia = abs(soma_quadrados - hipotenusa_quad) / hipotenusa_quad * 100
    ang_ingenuo = angulo_ingenuo_na_imagem(C_img, Vx, Vy)

    print(f"Ângulo 3D real entre as direções: 90°")
    print(f"Ângulo medido INGENUAMENTE na imagem (sem calibração): {ang_ingenuo:.2f}°")
    print(f"CVx²+CVy² = {soma_quadrados:.2f}, VxVy² = {hipotenusa_quad:.2f}")
    print(f"Discrepância (Pitágoras ingênuo): {discrepancia:.2f}%")
    print(f"{'CONFIRMADO: Pitágoras ingênuo falha mesmo com ângulo 3D real = 90°' if discrepancia > 0.5 else 'Pitágoras bateu (nao confirma a ressalva)'}")
    print(f"Ângulo recuperado via calibração (K^-1, já mostrado acima): {ang_recuperado:.4f}° -- bate com 90°")
