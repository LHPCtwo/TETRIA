from compress_demo import make_occ, build_quadtree, count_nodes

print(f"{'L':>8} {'k':>8} {'nos (real)':>12} {'3L-k (formula)':>16} {'bate?':>6}")
casos_ok = 0
casos_total = 0
for L in [16, 32, 64, 128, 256]:
    for frac in [1/8, 1/6, 1/4, 1/3, 3/8, 1/2]:
        k = int(L*frac)
        if k < 1: continue
        c = (L-k)//2
        size = 1
        while size < L: size *= 2
        occ = make_occ(L, k, c)
        tree = build_quadtree(occ, 0, 0, size)
        n = count_nodes(tree)
        formula = 3*L - k
        bate = "sim" if n == formula else "NAO"
        casos_total += 1
        if n == formula: casos_ok += 1
        print(f"{L:>8} {k:>8} {n:>12,} {formula:>16,} {bate:>6}")

print(f"\n{casos_ok}/{casos_total} casos bateram exatamente com nos = 3L - k")
