"""
Testa a afirmação: o hexágono achatado "baú" (padrão 3-4-3, linhas
empilhadas com espaçamento de grade quadrada ingênuo) vira o hexágono
regular (malha triangular verdadeira, 6 vizinhos equidistantes) por
uma ROTAÇÃO pura?

Rotação é uma isometria (preserva TODAS as distâncias). Se o "baú" tem
lados/diagonais de tamanhos diferentes do hexágono regular, nenhuma
rotação (nem translação) consegue igualar as distâncias -- seria
necessário escala e/ou cisalhamento (transformação afim geral, não
rígida).
"""
import numpy as np

def hexagono_bau_padrao_3_4_3():
    """
    Construção 'baú': linhas empilhadas de tamanhos 3,4,3 (ou k,k+1,k),
    usando ESPAÇAMENTO DE GRADE QUADRADA ingênuo (dx=1, dy=1 entre
    linhas -- NÃO a malha triangular verdadeira). Vértices do hexágono
    (contorno externo).
    """
    # linha do meio (y=0): 4 pontos, x=-1.5,-0.5,0.5,1.5
    # linha de cima (y=1): 3 pontos, x=-1,0,1
    # linha de baixo (y=-1): 3 pontos, x=-1,0,1
    topo = [(-1,1),(0,1),(1,1)]
    meio = [(-1.5,0),(-0.5,0),(0.5,0),(1.5,0)]
    fundo = [(-1,-1),(0,-1),(1,-1)]
    # vertices do contorno hexagonal (os 6 "cantos"): topo-esquerda,
    # topo-direita, meio-direita, fundo-direita, fundo-esquerda, meio-esquerda
    vertices = [(-1,1),(1,1),(1.5,0),(1,-1),(-1,-1),(-1.5,0)]
    return np.array(vertices, dtype=float)

def hexagono_regular_malha_triangular():
    """
    Hexágono regular de verdade: malha triangular equilátera, 6
    vizinhos a distância 1 do centro, ângulos de 60° entre si.
    """
    vertices = []
    for i in range(6):
        ang = i * np.pi / 3
        vertices.append((np.cos(ang), np.sin(ang)))
    return np.array(vertices, dtype=float)

def distancias_entre_vertices_consecutivos(vertices):
    n = len(vertices)
    return [np.linalg.norm(vertices[(i+1)%n] - vertices[i]) for i in range(n)]

def distancias_diagonais(vertices):
    """Distâncias entre vértices opostos (diagonais principais)."""
    n = len(vertices)
    return [np.linalg.norm(vertices[(i+n//2)%n] - vertices[i]) for i in range(n//2)]

if __name__ == "__main__":
    bau = hexagono_bau_padrao_3_4_3()
    regular = hexagono_regular_malha_triangular()

    print("=== Hexágono 'baú' (3-4-3, grade quadrada ingênua) ===")
    print("Vértices:", bau.tolist())
    lados_bau = distancias_entre_vertices_consecutivos(bau)
    diag_bau = distancias_diagonais(bau)
    print(f"Comprimentos dos lados: {[round(d,4) for d in lados_bau]}")
    print(f"Diagonais principais: {[round(d,4) for d in diag_bau]}")

    print("\n=== Hexágono regular (malha triangular verdadeira) ===")
    print("Vértices:", regular.tolist())
    lados_reg = distancias_entre_vertices_consecutivos(regular)
    diag_reg = distancias_diagonais(regular)
    print(f"Comprimentos dos lados: {[round(d,4) for d in lados_reg]}")
    print(f"Diagonais principais: {[round(d,4) for d in diag_reg]}")

    print("\n=== Teste: rotação pura preservaria essas distâncias? ===")
    print("Uma rotação (isometria) exige que os MULTICONJUNTOS de distâncias")
    print("(lados e diagonais) sejam idênticos nos dois hexágonos.")
    lados_iguais = sorted(round(d,4) for d in lados_bau) == sorted(round(d,4) for d in lados_reg)
    diag_iguais = sorted(round(d,4) for d in diag_bau) == sorted(round(d,4) for d in diag_reg)
    print(f"Lados batem (mesmo multiconjunto)? {lados_iguais}")
    print(f"Diagonais batem (mesmo multiconjunto)? {diag_iguais}")
    print(f"\nConclusão: {'ROTAÇÃO PURA BASTARIA' if (lados_iguais and diag_iguais) else 'ROTAÇÃO PURA NÃO BASTA -- precisa de escala/cisalhamento'}")
