"""
Teste de homogeneidade GEOMÉTRICO EXATO (Seção 9, "próximos passos" / Seção 17).

Em vez de amostrar 4 cantos + centro (heurística sujeita a falsos positivos
de homogeneidade quando k/L não está alinhado a potências de 2 -- ver
tabela3_alinhamento.py), este teste decide homogeneidade por interseção
analítica reta-retângulo:

  1. A região [x0,x0+size) x [y0,y0+size) cruza a hipotenusa (x+y=L) se
     min(x+y) < L <= max(x+y) dentro da região -- checagem O(1) via os
     dois extremos da região, não amostragem.

  2. Se a região está inteiramente dentro do triângulo (não cruza a
     hipotenusa), a homogeneidade depende só da relação com o bloco
     central B = [c,c+k) x [c,c+k):
       - região inteiramente DENTRO de B      -> homogênea, valor 2
       - região inteiramente FORA de B         -> homogênea, valor 1
       - overlap parcial (nem dentro nem fora) -> NÃO homogênea, subdivide

Esse teste é exato: nunca produz falso positivo de homogeneidade,
independente de k e c serem múltiplos de potência de 2 ou não.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class QuadNode:
    x0: int
    y0: int
    size: int
    value: Optional[int] = None
    children: Optional[list] = None


def _overlap_1d(a0, a1, b0, b1):
    """Interseção de dois intervalos fechados [a0,a1] e [b0,b1]."""
    return max(a0, b0), min(a1, b1)


def region_value_exact(L: int, k: int, c: int, x0: int, y0: int, size: int):
    """
    Retorna o valor único da região se ela for EXATAMENTE homogênea
    (sem amostragem, sem chance de falso positivo), ou None se cruza
    alguma fronteira e precisa subdividir.
    """
    x1, y1 = x0 + size - 1, y0 + size - 1  # última célula da região (inclusive)

    # --- 1. teste da hipotenusa: região cruza x+y=L? ---
    min_sum = x0 + y0
    max_sum = x1 + y1
    if min_sum < L <= max_sum:
        return None  # cruza a hipotenusa: parte dentro, parte fora do triângulo

    if min_sum >= L:
        return 0  # região inteira fora do triângulo -- homogênea

    # região inteira DENTRO do triângulo (max_sum < L): só falta checar o bloco
    if k <= 0:
        return 1  # sem bloco central: tudo é "malha" (T1+T2)

    bx0, bx1 = c, c + k - 1
    by0, by1 = c, c + k - 1

    ox0, ox1 = _overlap_1d(x0, x1, bx0, bx1)
    oy0, oy1 = _overlap_1d(y0, y1, by0, by1)
    overlap_x = ox0 <= ox1
    overlap_y = oy0 <= oy1

    if not (overlap_x and overlap_y):
        return 1  # nenhuma interseção com o bloco: região inteira fora dele

    inside_block = (x0 >= bx0 and x1 <= bx1 and y0 >= by0 and y1 <= by1)
    if inside_block:
        return 2  # região inteira dentro do bloco

    return None  # overlap parcial com o bloco: cruza a borda, precisa subdividir


def build_quadtree_exact(L: int, k: int, c: int, x0: int, y0: int, size: int) -> QuadNode:
    v = region_value_exact(L, k, c, x0, y0, size)
    if v is not None:
        return QuadNode(x0, y0, size, value=v)
    half = size // 2
    children = [
        build_quadtree_exact(L, k, c, x0,        y0,        half),
        build_quadtree_exact(L, k, c, x0 + half, y0,        half),
        build_quadtree_exact(L, k, c, x0,        y0 + half, half),
        build_quadtree_exact(L, k, c, x0 + half, y0 + half, half),
    ]
    return QuadNode(x0, y0, size, children=children)


def count_nodes(node: QuadNode) -> int:
    if node.children is None:
        return 1
    return 1 + sum(count_nodes(c) for c in node.children)


def query(node: QuadNode, x: int, y: int) -> int:
    if node.children is None:
        return node.value
    half = node.size // 2
    idx = (1 if x >= node.x0 + half else 0) + (2 if y >= node.y0 + half else 0)
    return query(node.children[idx], x, y)


def occ_ref(L, k, c, x, y):
    """Ocupação de referência (força bruta, para validar), mesmo esquema de
    valores 0/1/2 usado no teste exato."""
    if x + y >= L:
        return 0
    if c <= x < c + k and c <= y < c + k:
        return 2
    return 1


# ---------------------------------------------------------------------
# Validação: reconstrução ponto a ponto contra força bruta
# ---------------------------------------------------------------------

def valida_reconstrucao(L, k, n_amostras=3000, seed=0):
    import random
    random.seed(seed)
    c = (L - k) // 2
    size = 1
    while size < L:
        size *= 2
    tree = build_quadtree_exact(L, k, c, 0, 0, size)

    falhas = 0
    for _ in range(n_amostras):
        x = random.randrange(0, min(L, size))
        y = random.randrange(0, min(L, size))
        esperado = occ_ref(L, k, c, x, y)
        obtido = query(tree, x, y)
        if esperado != obtido:
            falhas += 1
    return falhas, count_nodes(tree)


# ---------------------------------------------------------------------
# Reproduz a Tabela 3 (Seção 9) com o teste EXATO, pra ver se o viés de
# alinhamento binário desaparece
# ---------------------------------------------------------------------

def tabela3_exata(L: int = 4096):
    fracoes = [("1/4", 1/4), ("1/6", 1/6), ("1/3", 1/3),
               ("3/8", 3/8), ("1/2", 1/2), ("5/8", 5/8)]
    print(f"--- Tabela 3 (teste EXATO): L={L} fixo, k/L variando ---")
    print(f"{'k/L':>6} {'k':>8} {'nos':>10} {'nos/L':>8}")
    resultados = []
    for label, frac in fracoes:
        k = max(1, int(L * frac))
        c = (L - k) // 2
        size = 1
        while size < L:
            size *= 2
        tree = build_quadtree_exact(L, k, c, 0, 0, size)
        n = count_nodes(tree)
        ratio = n / L
        print(f"{label:>6} {k:>8} {n:>10,} {ratio:>8.3f}")
        resultados.append((label, ratio))
    return resultados


if __name__ == "__main__":
    print("=== Validação de reconstrução (teste exato vs força bruta) ===")
    for L, k in [(16, 5), (64, 21), (256, 85), (256, 1)]:
        falhas, nodes = valida_reconstrucao(L, k)
        print(f"L={L:>4} k={k:>4}  nos={nodes:>7,}  falhas={falhas}/3000")

    print()
    resultados_exatos = tabela3_exata()

    print()
    print("=== Comparação lado a lado: heurística (amostragem) vs exata ===")
    print("(heurística: valores publicados na Tabela 3 do relatório / tabela3_alinhamento.py)")
    heuristica = {"1/4": 4.00, "1/6": 5.32, "1/3": 6.66, "3/8": 4.01, "1/2": 4.00, "5/8": 4.01}
    print(f"{'k/L':>6} {'heuristica':>12} {'exata':>10} {'diferenca':>12}")
    for label, ratio_exata in resultados_exatos:
        h = heuristica[label]
        print(f"{label:>6} {h:>12.3f} {ratio_exata:>10.3f} {ratio_exata-h:>12.3f}")

