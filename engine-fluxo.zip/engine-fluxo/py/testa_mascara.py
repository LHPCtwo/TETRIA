# Testa se "iQuadrado & repunitMask <= 1" é de fato um teste de MAGNITUDE
# (ou seja: se detecta corretamente "i pequeno") ou se é so um teste de
# PARIDADE/RESIDUO dos bits baixos de i^2 (o que e outra coisa).

def mask_test(i, k):
    repunit = (1 << k) - 1
    return (i*i) & repunit <= 1

def shift_test(i, k):
    # teste real de magnitude, tambem sem divisao: so shift.
    return (i >> k) == 0   # equivalente a i < 2^k

k = 4  # repunit = 15 (0000_1111)
falsos_positivos = []
for i in range(0, 256):
    m = mask_test(i, k)
    s = shift_test(i, k)
    if m != s:
        falsos_positivos.append((i, m, s))

print(f"k={k}, repunit={2**k-1}")
print(f"total de discordâncias entre mask_test e shift_test: {len(falsos_positivos)} / 256")
print("primeiros 15 exemplos (i, mask_test, shift_test):")
for row in falsos_positivos[:15]:
    print(" ", row)
