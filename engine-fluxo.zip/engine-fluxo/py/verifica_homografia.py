"""
Valida a matemática de homografia por rotação pura (mesmo centro
óptico), que é o modelo correto para "desenrolar" o ring buffer/scroll
como um cilindro: cada posição no anel = uma captura em ângulo
diferente, câmera girando no mesmo ponto -- resultado clássico de visão
computacional (panorama stitching): a relação entre duas imagens
tiradas do mesmo centro óptico é sempre uma homografia H = K R K^-1.

Teste de sanidade que só bate se a matemática estiver certa:
  H(theta1) @ H(theta2) ≈ H(theta1 + theta2)
(rotações em torno do mesmo eixo compõem por soma de ângulo; se a
homografia estiver certa, compor as duas matrizes tem que dar a mesma
matriz que já rotacionar direto pelo ângulo somado.)
"""
import numpy as np


def matriz_intrinseca(f, cx, cy):
    return np.array([
        [f, 0, cx],
        [0, f, cy],
        [0, 0, 1],
    ], dtype=float)


def rotacao_y(theta):
    """Rotação em torno do eixo Y (vertical) -- eixo natural para um
    scroll horizontal tipo cilindro."""
    c, s = np.cos(theta), np.sin(theta)
    return np.array([
        [c, 0, s],
        [0, 1, 0],
        [-s, 0, c],
    ], dtype=float)


def homografia_rotacao(K, theta):
    R = rotacao_y(theta)
    K_inv = np.linalg.inv(K)
    H = K @ R @ K_inv
    return H / H[2, 2]  # normaliza (homografia é definida a menos de escala)


def testa_composicao(K, theta1, theta2, tol=1e-9):
    H1 = homografia_rotacao(K, theta1)
    H2 = homografia_rotacao(K, theta2)
    H_composta = H1 @ H2
    H_composta = H_composta / H_composta[2, 2]

    H_direta = homografia_rotacao(K, theta1 + theta2)

    diff = np.abs(H_composta - H_direta).max()
    return diff < tol, diff, H_composta, H_direta


def testa_pontos_projetados(K, theta, ponto_3d):
    """
    Verifica que projetar um ponto 3D pela câmera 0 e depois aplicar a
    homografia dá o mesmo resultado que projetar o ponto 3D diretamente
    pela câmera rotacionada -- é essa a propriedade que faz a homografia
    ser útil pra warp de imagem sem saber a geometria 3D de novo.
    """
    R = rotacao_y(theta)
    ponto_3d = np.array(ponto_3d, dtype=float)

    # projeção pela câmera 0 (identidade)
    p0 = K @ ponto_3d
    p0 = p0[:2] / p0[2]

    # projeção pela câmera rotacionada (R aplicado ao ponto no referencial da camera)
    ponto_rotacionado = R @ ponto_3d
    p_theta = K @ ponto_rotacionado
    p_theta = p_theta[:2] / p_theta[2]

    # aplica a homografia ao ponto p0 (em coordenadas homogêneas 2D)
    H = homografia_rotacao(K, theta)
    p0_hom = np.array([p0[0], p0[1], 1.0])
    p_via_H = H @ p0_hom
    p_via_H = p_via_H[:2] / p_via_H[2]

    diff = np.abs(p_via_H - p_theta).max()
    return diff, p_theta, p_via_H


if __name__ == "__main__":
    K = matriz_intrinseca(f=500.0, cx=128.0, cy=128.0)

    print("=== Teste 1: composição de homografias (H1 @ H2 == H(theta1+theta2)) ===")
    casos = [(0.1, 0.2), (0.05, 0.05), (-0.3, 0.3), (0.7, 0.1)]
    todos_ok = True
    for t1, t2 in casos:
        ok, diff, _, _ = testa_composicao(K, t1, t2)
        todos_ok &= ok
        print(f"  theta1={t1:.2f} theta2={t2:.2f}: diff_max={diff:.2e} {'OK' if ok else 'FALHOU'}")
    print(f"Todos os casos de composição batem? {todos_ok}")

    print("\n=== Teste 2: projeção direta vs via homografia (mesmo ponto 3D) ===")
    pontos_3d = [(10, 5, 100), (-20, 10, 150), (0, 0, 200), (30, -15, 80)]
    thetas = [0.1, 0.3, -0.2]
    todos_ok2 = True
    for theta in thetas:
        for p in pontos_3d:
            diff, p_direto, p_via_h = testa_pontos_projetados(K, theta, p)
            ok = diff < 1e-6
            todos_ok2 &= ok
            if not ok:
                print(f"  theta={theta} ponto={p}: diff={diff:.2e} FALHOU")
    print(f"Todos os {len(thetas)*len(pontos_3d)} casos de projeção batem? {todos_ok2}")

    print("\n=== Teste 3: desenrolar o anel completo (m posições, ring buffer) ===")
    m = 8  # mesmo conceito do WindowController: m posições no anel
    print(f"m={m} posições no anel, ângulo entre posições = 2π/{m} = {2*np.pi/m:.4f} rad")
    for i in range(m):
        theta_i = 2 * np.pi * i / m
        H_i = homografia_rotacao(K, theta_i)
        print(f"  posição {i}: theta={theta_i:.4f} rad, H[0,2] (deslocamento horizontal aprox)={H_i[0,2]:.2f}")

    print("\n=== Teste 4: por que homografia de plano ÚNICO não serve pro anel inteiro ===")
    print("Uma homografia relaciona dois planos -- degenera quando theta -> 90 graus")
    print("(tan(theta) diverge). Testando o determinante de H perto de theta=pi/2:")
    for theta_deg in [10, 30, 60, 80, 89, 91, 120, 170]:
        theta = np.radians(theta_deg)
        H = homografia_rotacao(K, theta)
        det = np.linalg.det(H)
        print(f"  theta={theta_deg:>4}°: det(H)={det:>14.2f}  {'degenerando' if abs(theta_deg-90)<15 else ''}")
    print()
    print("Conclusão: homografia de UM plano só funciona bem para ângulos pequenos")
    print("(tipicamente < ~60-80° de FOV). Para desenrolar o anel inteiro (360°), a")
    print("projeção global tem que ser CILÍNDRICA (não-linear, sem esse problema de")
    print("divergência) -- homografia serve para alinhar/deformar cada fatia individual")
    print("contra suas vizinhas próximas (ângulo pequeno entre posições consecutivas do")
    print("anel), não para mapear o anel inteiro num plano único.")
